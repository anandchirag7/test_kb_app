-- =============================
-- KB INGEST FULL SCHEMA
-- =============================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- =============================
-- FILES TABLE
-- =============================
CREATE TABLE IF NOT EXISTS files (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename        TEXT NOT NULL,
    storage_path    TEXT,
    filesize_bytes  BIGINT,
    content_hash    TEXT UNIQUE,
    source          TEXT,
    product_family  TEXT,
    uploaded_by     TEXT,
    processed_at    TIMESTAMP,
    created_at      TIMESTAMP DEFAULT now()
);

-- =============================
-- PROCESSING JOBS
-- =============================
CREATE TABLE IF NOT EXISTS processing_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES files(id),
    status TEXT,
    error TEXT,
    started_at TIMESTAMP,
    finished_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT now()
);

-- =============================
-- CHUNKS
-- =============================
CREATE TABLE IF NOT EXISTS chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES files(id),
    page_number INT,
    type TEXT, -- text | image | table
    chunk_index INT,
    bbox JSONB,
    text TEXT,
    storage_path TEXT,
    thumbnail_path TEXT,
    embedding vector(1536),
    embedding_model TEXT,
    detected_entities JSONB,
    language TEXT,
    chunk_len_tokens INT,
    confidence FLOAT,
    created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file_id);
CREATE INDEX IF NOT EXISTS idx_chunks_page ON chunks(page_number);
CREATE INDEX IF NOT EXISTS idx_chunks_tsv ON chunks USING GIN (to_tsvector('english', text));
CREATE INDEX IF NOT EXISTS idx_chunks_embedding ON chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- =============================
-- TABLES (extracted)
-- =============================
CREATE TABLE IF NOT EXISTS extracted_tables (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES files(id),
    page_number INT,
    table_json JSONB,
    normalized_csv TEXT,
    row_embeddings JSONB,
    created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_extracted_tables_file ON extracted_tables(file_id);

-- =============================
-- ANNOTATIONS
-- =============================
CREATE TABLE IF NOT EXISTS annotations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES files(id),
    page_number INT,
    annotator TEXT,
    entity TEXT,
    notes TEXT,
    bbox JSONB,
    created_at TIMESTAMP DEFAULT now()
);

-- =============================
-- AUDIT LOGS
-- =============================
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action TEXT,
    payload JSONB,
    created_at TIMESTAMP DEFAULT now()
);
