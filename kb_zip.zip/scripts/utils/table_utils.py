"""
table_utils.py

Utility helpers for manipulating table_json objects, handling
merged cells, resolving spans, and normalizing table values.

Used by:
- table_extractor.py
- pdf_ingest.py (optional merge-duplication)
- table_reader.py
"""

from typing import List, Dict, Any, Optional


# ------------------------------------------------------------
# Basic type inference
# ------------------------------------------------------------
def infer_type(val: str) -> str:
    """Return 'number' or 'string' based on heuristics."""
    if not val:
        return "string"
    v = val.replace(",", "").strip()
    try:
        float(v)
        return "number"
    except:
        return "string"


# ------------------------------------------------------------
# Duplicate merged-cell anchor text into covered cells
# ------------------------------------------------------------
def expand_merged_cells(cells: List[Dict[str, Any]], rows: int, cols: int):
    """
    Duplicate merged-cell anchor text (optional ingestion behavior).
    Input cells is the list of cell dict objects with keys:
      r, c, rowspan, colspan, text, bbox, ...
    Returns new 2D array rows x cols with duplicated text.

    This is not meant to alter the original cell objects but rather
    build a matrix form for convenience.
    """
    # initialize empty matrix
    matrix = [["" for _ in range(cols)] for _ in range(rows)]

    for c in cells:
        r = c["r"]
        col = c["c"]
        rs = c.get("rowspan", 1)
        cs = c.get("colspan", 1)
        txt = (c.get("text") or "").strip()

        for rr in range(r, min(rows, r + rs)):
            for cc in range(col, min(cols, col + cs)):
                # basic rule: fill anchor text everywhere
                matrix[rr][cc] = txt

    return matrix


# ------------------------------------------------------------
# Making flattened_rows rectangular
# ------------------------------------------------------------
def normalize_rectangular(table_json: Dict[str, Any]) -> List[List[str]]:
    """
    Ensures that table_json['flattened_rows'] is rectangular
    by padding missing cells with "".

    Returns the new rectangular 2D array.
    """
    fr = table_json.get("flattened_rows") or []
    if not fr:
        return []

    maxc = max(len(r) for r in fr)
    fixed = []
    for row in fr:
        r = list(row)
        while len(r) < maxc:
            r.append("")
        fixed.append(r)
    return fixed


# ------------------------------------------------------------
# Merged-cell to full matrix (duplicate anchor text)
# ------------------------------------------------------------
def build_full_matrix_from_cells(cells: List[Dict[str, Any]]) -> List[List[str]]:
    """
    If the extractor provided cell span info, this builds
    a full 2D text matrix by duplicating anchor text across spans.

    rows = max(r + rowspan)
    cols = max(c + colspan)
    """
    if not cells:
        return []

    max_r = 0
    max_c = 0
    for c in cells:
        r = c["r"]
        col = c["c"]
        rs = c.get("rowspan", 1)
        cs = c.get("colspan", 1)
        max_r = max(max_r, r + rs)
        max_c = max(max_c, col + cs)

    matrix = [["" for _ in range(max_c)] for _ in range(max_r)]

    for c in cells:
        r = c["r"]
        col = c["c"]
        rs = c.get("rowspan", 1)
        cs = c.get("colspan", 1)
        txt = (c.get("text") or "").strip()

        for rr in range(r, r + rs):
            for cc in range(col, col + cs):
                matrix[rr][cc] = txt

    return matrix


# ------------------------------------------------------------
# Header detection
# ------------------------------------------------------------
def detect_header_rows(matrix: List[List[str]]) -> int:
    """
    Simple heuristic: if the first row has mostly strings
    and second row has mostly numbers, assume 1 header row.

    Returns: number of header rows (often 1).
    """
    if not matrix:
        return 0
    if len(matrix) == 1:
        return 1

    row0 = matrix[0]
    row1 = matrix[1]

    row0_num = sum(1 for v in row0 if infer_type(v) == "number")
    row1_num = sum(1 for v in row1 if infer_type(v) == "number")

    # first row mostly strings, second row mostly numbers => header
    if row0_num < len(row0)/2 and row1_num > len(row1)/2:
        return 1
    return 0


# ------------------------------------------------------------
# Normalize full table_json
# ------------------------------------------------------------
def normalize_table_json(table_json: Dict[str, Any], duplicate_merged: bool = False) -> Dict[str, Any]:
    """
    Ensures table_json has:
        - rectangular flattened_rows
        - header_row_count guessed if missing
        - row_count, col_count filled in

    If duplicate_merged=True, use expanded matrix (merged cell duplication).
    """
    table_json = table_json.copy()

    # If we have cell spans, consider building a full matrix
    cells = table_json.get("cells", [])
    if duplicate_merged and cells:
        matrix = build_full_matrix_from_cells(cells)
        table_json["flattened_rows"] = matrix
    else:
        # fallback to provided matrix
        fr = table_json.get("flattened_rows") or []
        table_json["flattened_rows"] = normalize_rectangular(table_json)

    fr = table_json["flattened_rows"]
    table_json["row_count"] = len(fr)
    table_json["col_count"] = max((len(r) for r in fr), default=0)

    # header row detection if missing
    header_rc = table_json.get("header_row_count")
    if header_rc is None:
        table_json["header_row_count"] = detect_header_rows(fr)

    return table_json
# ---------------------------------------------
# END OF FILE