"""
chunk_utils.py

Utility functions used across ingestion, table extraction,
and KG building for handling bounding boxes, TSV conversion,
chunk normalization, confidence heuristics, and overlap metrics.

Used by:
- pdf_ingest.py
- neo4j_build_kg.py
- table_reader
- provenance_utils
"""

import json
import math
from typing import List, Dict, Any, Optional


# ------------------------------------------------------------
# General helpers
# ------------------------------------------------------------

def to_tsvector(text: str) -> str:
    """
    Postgres tsvector builder (simple escape). In practice this is applied
    in DB via to_tsvector('english', text), but for test mocks this helps.
    """
    if not text:
        return ""
    # basic normalization
    cleaned = text.replace("'", " ").replace('"', " ")
    return cleaned


def normalize_whitespace(s: str) -> str:
    if not s:
        return ""
    return " ".join(s.split())


# ------------------------------------------------------------
# Bounding box geometry helpers
# ------------------------------------------------------------

def clean_bbox(bbox: Any) -> Optional[List[float]]:
    """
    Normalize bbox into [x0, y0, x1, y1] floats.
    Accepts JSON string or list/tuple. Returns None if invalid.
    """
    if bbox is None:
        return None

    # If string, try to parse
    if isinstance(bbox, str):
        try:
            bbox = json.loads(bbox)
        except Exception:
            return None

    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        return None

    try:
        x0, y0, x1, y1 = map(float, bbox)
    except Exception:
        return None

    if x1 <= x0 or y1 <= y0:
        # invalid / empty
        return None

    return [x0, y0, x1, y1]


def bbox_area(b: List[float]) -> float:
    if not b:
        return 0.0
    x0, y0, x1, y1 = b
    return max(0.0, (x1 - x0) * (y1 - y0))


def bbox_intersection(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b

    ix0 = max(ax0, bx0)
    iy0 = max(ay0, by0)
    ix1 = min(ax1, bx1)
    iy1 = min(ay1, by1)

    iw = max(0.0, ix1 - ix0)
    ih = max(0.0, iy1 - iy0)
    return iw * ih


def bbox_iou(a: Optional[List[float]], b: Optional[List[float]]) -> float:
    """Intersection over union with safety guards."""
    if not a or not b:
        return 0.0
    inter = bbox_intersection(a, b)
    area_a = bbox_area(a)
    area_b = bbox_area(b)
    denom = area_a + area_b - inter
    if denom <= 0:
        return 0.0
    return inter / denom


# ------------------------------------------------------------
# Chunk scoring and confidence utilities
# ------------------------------------------------------------

def token_length(text: str) -> int:
    """Rough token length (approximate to GPT-style ~4 chars/token)."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def compute_confidence(text: str) -> float:
    """Basic heuristic: longer, clearer text = higher."""
    if not text:
        return 0.3
    if len(text) < 5:
        return 0.5
    if len(text) < 20:
        return 0.7
    return 0.9


# ------------------------------------------------------------
# Provenance mapping helpers
# ------------------------------------------------------------

def bbox_center(b: List[float]) -> Optional[List[float]]:
    if not b:
        return None
    x0, y0, x1, y1 = b
    return [(x0 + x1) / 2.0, (y0 + y1) / 2.0]


def point_in_bbox(px: float, py: float, b: List[float]) -> bool:
    if not b:
        return False
    x0, y0, x1, y1 = b
    return (x0 <= px <= x1) and (y0 <= py <= y1)


def most_overlapping_cell(chunk_bbox: List[float], cells: List[Dict[str, Any]]):
    """
    Given a chunk bbox, find the single best cell by IoU.
    Returns: (cell, iou)
    """
    best_cell = None
    best_iou = 0.0

    for c in cells:
        cb = clean_bbox(c.get("bbox"))
        if not cb:
            continue
        iou = bbox_iou(chunk_bbox, cb)
        if iou > best_iou:
            best_iou = iou
            best_cell = c

    return best_cell, best_iou
# ---------------------------------------------
# END OF FILE   