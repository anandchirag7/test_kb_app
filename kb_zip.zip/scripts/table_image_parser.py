#!/usr/bin/env python3
"""
table_image_parser.py

Image-based table parser using OpenCV + pytesseract.

Produces table_json objects like:
{
  "cells": [
    {"id":"c0","r":0,"c":0,"rowspan":1,"colspan":1,"bbox":[x0,y0,x1,y1],"text":"12.3","raw_text":"12.3","confidence":0.95,"type":"number"},
    ...
  ],
  "flattened_rows": [
    ["A","B","C"],
    ["1","2","3"]
  ]
}

Primary entrypoint:
    parse_page_image(pil_image, lang="eng", detect_min_area=2000)

Notes:
- Best-effort: robust to many table styles but not perfect for every PDF image.
- Requires: opencv-python, pytesseract, Pillow, numpy
"""

from typing import List, Dict, Any, Tuple
import numpy as np
import cv2
from PIL import Image
from knowledge_base.scripts.pdf_table_plumber import _looks_like_number
import pytesseract
import math
import uuid
import logging

logger = logging.getLogger("table_image_parser")
logging.basicConfig(level=logging.INFO)


# -------------------------
# Utilities
# -------------------------
def pil_to_cv2(pil_img: Image.Image) -> np.ndarray:
    """Convert PIL.Image to OpenCV BGR image"""
    arr = np.array(pil_img)
    if arr.ndim == 2:
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
    if arr.shape[2] == 4:
        return cv2.cvtColor(arr, cv2.COLOR_RGBA2BGR)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def normalize_bbox(box: Tuple[int, int, int, int]) -> List[int]:
    x, y, w, h = box
    return [int(x), int(y), int(x + w), int(y + h)]


def safe_ocr_crop(img_cv, bbox):
    x0, y0, x1, y1 = bbox
    h, w = img_cv.shape[:2]
    x0 = max(0, int(x0)); y0 = max(0, int(y0)); x1 = min(w, int(x1)); y1 = min(h, int(y1))
    if x1 <= x0 or y1 <= y0:
        return ""
    crop = img_cv[y0:y1, x0:x1]
    # pre-process crop for OCR
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    # threshold - adaptive helps with variable backgrounds
    try:
        th = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, 15, 6)
    except Exception:
        _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # enlarge a bit for tesseract clarity
    scale = 2.0
    h2, w2 = th.shape
    th_up = cv2.resize(th, (int(w2*scale), int(h2*scale)), interpolation=cv2.INTER_LINEAR)
    # Convert back to PIL for pytesseract (keeps configuration flexible)
    pil = Image.fromarray(th_up)
    text = pytesseract.image_to_string(pil, config="--psm 6")
    return text.strip()


# -------------------------
# Core table detection
# -------------------------
def detect_table_contours(img_gray: np.ndarray, min_area: int = 2000):
    """
    Detect rectangular contours that look like table or table cells using morphological ops.
    Returns list of bounding boxes (x, y, w, h) sorted top-left -> bottom-right.
    """
    # binarize
    blur = cv2.GaussianBlur(img_gray, (3, 3), 0)
    _, bw = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    bw = 255 - bw  # invert: table lines become white

    # morphological operations to find lines
    kernel_len = max(10, img_gray.shape[1] // 100)
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_len))
    hor_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_len, 1))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))

    vertical_lines = cv2.morphologyEx(bw, cv2.MORPH_OPEN, vert_kernel, iterations=1)
    horizontal_lines = cv2.morphologyEx(bw, cv2.MORPH_OPEN, hor_kernel, iterations=1)
    mask = cv2.addWeighted(vertical_lines, 0.5, horizontal_lines, 0.5, 0.0)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    # find contours on mask
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if w * h < min_area:
            continue
        # filter out very narrow or small boxes
        boxes.append((x, y, w, h))

    # sort by y then x
    boxes = sorted(boxes, key=lambda b: (b[1], b[0]))
    return boxes, mask


def infer_grid_from_boxes(boxes: List[Tuple[int, int, int, int]], tolerance=10):
    """
    Given detected boxes (likely cells or groups), cluster them into rows/columns.
    Returns grid (rows x cols) with each cell bbox or None.
    """
    if not boxes:
        return []

    # compute row clusters based on y coordinate
    rows = []
    for b in boxes:
        x, y, w, h = b
        placed = False
        for r in rows:
            # compare with first element y of row
            rx, ry, rw, rh = r[0]
            if abs(y - ry) <= tolerance:
                r.append(b)
                placed = True
                break
        if not placed:
            rows.append([b])

    # sort boxes in each row by x
    rows = [sorted(r, key=lambda b: b[0]) for r in rows]

    # determine cols by aligning x coordinates of the first row (approx)
    # Build grid: rows x max_cols
    max_cols = max(len(r) for r in rows)
    grid = []
    for r in rows:
        # pad row to max_cols with None
        row_cells = list(r) + [None] * (max_cols - len(r))
        grid.append(row_cells)

    return grid


def merge_overlapping_cells(grid: List[List[Tuple[int, int, int, int]]]):
    """
    Convert grid of bboxes into normalized cell list with (x0,y0,x1,y1).
    Also returns average cell width/height to help guess rowspan/colspan.
    """
    norm_grid = []
    widths = []
    heights = []
    for row in grid:
        norm_row = []
        for cell in row:
            if cell is None:
                norm_row.append(None)
                continue
            x, y, w, h = cell
            bbox = [int(x), int(y), int(x + w), int(y + h)]
            widths.append(w)
            heights.append(h)
            norm_row.append(bbox)
        norm_grid.append(norm_row)

    avg_w = int(np.median(widths)) if widths else 0
    avg_h = int(np.median(heights)) if heights else 0
    return norm_grid, avg_w, avg_h


def compute_rowspan_colspan(norm_grid: List[List[List[int]]], avg_w: int, avg_h: int):
    """
    Detect merged cells giving rowspan/colspan > 1 by checking bbox sizes relative to averages.
    Returns cells info list with r,c,rowspan,colspan,bbox
    """
    cells = []
    rows = len(norm_grid)
    cols = max(len(r) for r in norm_grid) if rows else 0
    used = [[False] * cols for _ in range(rows)]

    for r in range(rows):
        for c in range(len(norm_grid[r])):
            if used[r][c]:
                continue
            bbox = norm_grid[r][c]
            if bbox is None:
                continue
            x0, y0, x1, y1 = bbox
            w = x1 - x0
            h = y1 - y0

            # estimate colspan, rowspan by dividing against avg
            colspan = max(1, int(round(w / max(1, avg_w))))
            rowspan = max(1, int(round(h / max(1, avg_h))))

            # cap spans so they don't exceed grid boundary
            colspan = min(colspan, cols - c)
            rowspan = min(rowspan, rows - r)

            # mark used cells
            for rr in range(r, r + rowspan):
                for cc in range(c, c + colspan):
                    if rr < rows and cc < len(norm_grid[rr]):
                        used[rr][cc] = True

            cells.append({
                "r": r,
                "c": c,
                "rowspan": rowspan,
                "colspan": colspan,
                "bbox": bbox
            })
    return cells


# -------------------------
# High-level parse function
# -------------------------
def parse_page_image(pil_image: Image.Image, lang: str = "eng", detect_min_area: int = 2000) -> List[Dict[str, Any]]:
    """
    Parse a PIL image of a page and extract table(s) present.

    Returns list of table_json dicts.
    """
    img_cv = pil_to_cv2(pil_image)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

    # detect boxes that look like table structures
    boxes, mask = detect_table_contours(gray, min_area=detect_min_area)

    results = []

    if not boxes:
        # fallback: do OCR for the whole page, try to split lines as a single table
        logger.info("No table contours detected — fallback OCR split")
        whole_text = pytesseract.image_to_string(pil_image, config="--psm 3")
        lines = [ln.strip() for ln in whole_text.splitlines() if ln.strip()]
        if not lines:
            return []
        # naive split by multiple whitespace/tabs
        rows = [list(filter(None, [c.strip() for c in ln.split()])) for ln in lines]
        # ensure rectangular: pad
        maxc = max(len(r) for r in rows)
        for r in rows:
            while len(r) < maxc:
                r.append("")
        table_json = {
            "cells": [],
            "flattened_rows": rows,
            "origin": {"method": "ocr_fallback"}
        }
        # Build cells without bbox
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                table_json["cells"].append({
                    "id": f"c_{ri}_{ci}",
                    "r": ri, "c": ci, "rowspan": 1, "colspan": 1,
                    "bbox": None, "text": val, "raw_text": val, "confidence": 0.6, "type": "string"
                })
        return [table_json]

    # Group boxes into grid like structures
    grid = infer_grid_from_boxes(boxes, tolerance=max(8, int(pil_image.size[1] * 0.005)))
    norm_grid, avg_w, avg_h = merge_overlapping_cells(grid)
    # detect cell spans
    cell_spans = compute_rowspan_colspan(norm_grid, avg_w, avg_h)

    # build cells with OCR
    cells_out = []
    # create an empty 2D array for flattened rows filled with empty strings
    rows_n = len(norm_grid)
    cols_n = max(len(r) for r in norm_grid) if rows_n else 0
    flattened = [["" for _ in range(cols_n)] for _ in range(rows_n)]

    for idx, cell in enumerate(cell_spans):
        r = cell["r"]; c = cell["c"]
        rs = cell["rowspan"]; cs = cell["colspan"]
        bbox = cell["bbox"]  # [x0,y0,x1,y1]
        # OCR the bbox
        text = safe_ocr_crop(img_cv, bbox)
        # normalize text
        text_clean = " ".join(text.split()).strip()
        cell_id = f"c_{r}_{c}_{idx}_{uuid.uuid4().hex[:6]}"
        # guess type
        typ = "number" if _looks_like_number(text_clean) else "string"
        confidence = 0.9 if text_clean else 0.5

        cells_out.append({
            "id": cell_id,
            "r": r,
            "c": c,
            "rowspan": rs,
            "colspan": cs,
            "bbox": bbox,
            "text": text_clean,
            "raw_text": text,
            "confidence": confidence,
            "type": typ
        })

        # Fill flattened cells for the covered area
        for rr in range(r, min(rows_n, r + rs)):
            for cc in range(c, min(len(norm_grid[rr]), c + cs)):
                flattened[rr][cc] = text_clean

    # Postprocess: ensure no empty rows/cols at edges
    # trim trailing empty columns
    # But keep structure as is to preserve coordinates
    table_json = {
        "cells": cells_out,
        "flattened_rows": flattened,
        "origin": {"method": "image_parser"}
    }
    results.append(table_json)
    return results


# -------------------------
# CLI for local testing
# -------------------------
if __name__ == "__main__":
    import argparse
    from PIL import Image

    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True, help="Path to page image (PNG/JPG)")
    ap.add_argument("--lang", default="eng")
    ap.add_argument("--min_area", type=int, default=2000)
    args = ap.parse_args()

    pil = Image.open(args.image).convert("RGB")
    tables = parse_page_image(pil, lang=args.lang, detect_min_area=args.min_area)
    import json
    print(json.dumps(tables, indent=2))
