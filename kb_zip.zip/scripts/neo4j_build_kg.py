#!/usr/bin/env python3
"""
neo4j_build_kg.py — FINAL KNOWLEDGE GRAPH BUILDER

Builds the full graph for each PDF:
- Document, Page
- Table, Row, Cell
- Chunk (text/table/image)
- Image (with storage_path + bbox)
- COVERS_CELL / REFERENCES_CELL edges (bbox IoU)
- MENTIONS_ENTITY edges (via LLMNER)
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional

import psycopg2
import psycopg2.extras
from neo4j import GraphDatabase, basic_auth
import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("neo4j_build_kg")

# -----------------------
# ENV
# -----------------------
DATABASE_URL = os.environ.get("DATABASE_URL")
NEO4J_URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.environ.get("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD", "neo4j")
INFERENCE_API_URL = os.environ.get("INFERENCE_API_URL")
INFERENCE_API_KEY = os.environ.get("INFERENCE_API_KEY")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL not set")

# -----------------------
# DB CONNECTORS
# -----------------------
def get_pg_conn():
    return psycopg2.connect(DATABASE_URL)

def get_neo_driver():
    return GraphDatabase.driver(
        NEO4J_URI, auth=basic_auth(NEO4J_USER, NEO4J_PASSWORD)
    )

# -----------------------
# ENTITY EXTRACTION (optional)
# -----------------------
def call_entity_extraction(texts: List[str]) -> List[List[Dict[str, Any]]]:
    """
    LLM-based NER for each text in `texts`.
    Returns a list of: [ [ {id, text, type, confidence}, ...], ... ]
    """
    if not INFERENCE_API_URL:
        return [[] for _ in texts]

    headers = {}
    if INFERENCE_API_KEY:
        headers["Authorization"] = f"Bearer {INFERENCE_API_KEY}"

    try:
        resp = requests.post(
            INFERENCE_API_URL,
            json={"inputs": texts},
            headers=headers,
            timeout=60
        )
        resp.raise_for_status()
        data = resp.json()

        # normalize
        if isinstance(data, dict) and "data" in data:
            return [item.get("entities", []) for item in data["data"]]

        if isinstance(data, list):
            return [item.get("entities", []) if isinstance(item, dict) else [] for item in data]

    except Exception as e:
        logger.error("Entity extraction failed: %s", e)

    return [[] for _ in texts]


# -----------------------
# CYPHER TEMPLATES
# -----------------------

CREATE_DOCUMENT = """
MERGE (d:Document {id:$doc_id})
SET d.filename=$filename,
    d.content_hash=$content_hash,
    d.filesize_bytes=$filesize,
    d.source=$source,
    d.product_family=$product_family,
    d.processed_at=$processed_at,
    d.created_at = coalesce(d.created_at, datetime())
"""

CREATE_PAGE = """
MERGE (p:Page {doc_id:$doc_id, page_number:$page_number})
SET p.width=$width, p.height=$height
"""

CREATE_TABLE = """
MERGE (t:Table {id:$table_id})
SET t.row_count=$row_count,
    t.col_count=$col_count,
    t.header_row_count=$header_row_count,
    t.origin_method=$method
WITH t
MATCH (p:Page {doc_id:$doc_id, page_number:$page_number})
MERGE (p)-[:HAS_TABLE]->(t)
"""

CREATE_ROW = """
MERGE (r:Row {table_id:$table_id, row_index:$row_index})
WITH r
MATCH (t:Table {id:$table_id})
MERGE (t)-[:HAS_ROW]->(r)
"""

CREATE_CELL = """
MERGE (c:Cell {table_id:$table_id, r:$r, c:$c})
SET c.rowspan=$rowspan,
    c.colspan=$colspan,
    c.text=$text,
    c.raw_text=$raw_text,
    c.confidence=$confidence,
    c.bbox=$bbox
WITH c
MATCH (r:Row {table_id:$table_id, row_index:$row_index})
MERGE (r)-[:HAS_CELL]->(c)
"""

CREATE_CHUNK = """
MERGE (ck:Chunk {id:$chunk_id})
SET ck.type=$type,
    ck.text=$text,
    ck.page_number=$page_number,
    ck.chunk_index=$chunk_index,
    ck.embedding_model=$embedding_model,
    ck.created_at = coalesce(ck.created_at, datetime())
WITH ck
MATCH (d:Document {id:$doc_id})
MERGE (d)-[:HAS_CHUNK]->(ck)
"""

CREATE_IMAGE = """
MERGE (img:Image {id:$img_id})
SET img.file_id=$file_id,
    img.page_number=$page_number,
    img.storage_path=$storage_path,
    img.thumbnail_path=$thumbnail_path,
    img.bbox=$bbox,
    img.width=$width,
    img.height=$height,
    img.ocr_text=$ocr_text,
    img.caption=$caption,
    img.embedding_ref=$embedding_ref,
    img.chunk_id=$chunk_id,
    img.created_at = coalesce(img.created_at, datetime())
WITH img
MATCH (d:Document {id:$file_id})
MERGE (d)-[:HAS_IMAGE]->(img)
"""

CREATE_CHUNK_REF_CELL = """
MATCH (ck:Chunk {id:$chunk_id})
MATCH (c:Cell {table_id:$table_id, r:$r, c:$c})
MERGE (ck)-[rel:REFERENCES_CELL]->(c)
SET rel.file_id=$file_id,
    rel.page_number=$page_number,
    rel.bbox=$bbox,
    rel.score=$score
"""

CREATE_IMAGE_COVERS_CELL = """
MATCH (img:Image {id:$img_id})
MATCH (c:Cell {table_id:$table_id, r:$r, c:$c})
MERGE (img)-[rel:COVERS_CELL]->(c)
SET rel.iou=$iou,
    rel.created_at = coalesce(rel.created_at, datetime())
"""
# -----------------------
# BBOX IOU util (local helper)
# -----------------------
def bbox_iou(a, b):
    """
    Compute IoU for two bboxes in [x0,y0,x1,y1] format.
    Returns 0.0..1.0
    """
    if not a or not b:
        return 0.0
    try:
        ax0, ay0, ax1, ay1 = map(float, a)
        bx0, by0, bx1, by1 = map(float, b)
    except Exception:
        return 0.0

    ix0 = max(ax0, bx0)
    iy0 = max(ay0, by0)
    ix1 = min(ax1, bx1)
    iy1 = min(ay1, by1)

    iw = max(0.0, ix1 - ix0)
    ih = max(0.0, iy1 - iy0)
    inter = iw * ih
    area_a = max(1e-9, (ax1 - ax0) * (ay1 - ay0))
    area_b = max(1e-9, (bx1 - bx0) * (by1 - by0))
    union = area_a + area_b - inter
    if union <= 0:
        return 0.0
    return inter / union


# -----------------------
# Core KG builder functions
# -----------------------
def build_kg_for_all_docs(limit: Optional[int] = None, offset: int = 0):
    pg = get_pg_conn()
    driver = get_neo_driver()
    try:
        with pg.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT id, filename, content_hash, filesize_bytes, source, product_family, processed_at, created_at
                FROM files
                ORDER BY created_at ASC
                LIMIT %s OFFSET %s
            """, (limit or 1000000, offset))
            files = cur.fetchall()

        logger.info("Found %d files to process", len(files))
        for f in files:
            process_single_file(pg, driver, f)
    finally:
        pg.close()
        driver.close()


def process_single_file(pg_conn, neo_driver, file_row: Dict[str, Any]):
    """
    Ingest one file's extracted artifacts into Neo4j.
    """
    doc_id = str(file_row["id"])
    logger.info("Processing file %s (%s)", doc_id, file_row.get("filename"))

    # Create Document node
    with neo_driver.session() as sess:
        sess.run(CREATE_DOCUMENT, {
            "doc_id": doc_id,
            "filename": file_row.get("filename"),
            "content_hash": file_row.get("content_hash"),
            "filesize": file_row.get("filesize_bytes"),
            "source": file_row.get("source"),
            "product_family": file_row.get("product_family"),
            "processed_at": file_row.get("processed_at")
        })

    # Load extracted_tables for this document
    with pg_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT id, page_number, table_json
            FROM extracted_tables
            WHERE file_id = %s
            ORDER BY page_number
        """, (doc_id,))
        tables = cur.fetchall()

    # Create Page / Table / Row / Cell nodes
    for t in tables:
        table_id = str(t["id"])
        table_json = t.get("table_json") or {}
        page_number = int(t.get("page_number") or 0)

        row_count = table_json.get("row_count")
        col_count = table_json.get("col_count")
        header_row_count = table_json.get("header_row_count") or 0
        method = (table_json.get("origin") or {}).get("method") if isinstance(table_json, dict) else None

        with neo_driver.session() as sess:
            sess.run(CREATE_PAGE, {"doc_id": doc_id, "page_number": page_number, "width": None, "height": None})
            sess.run(CREATE_TABLE, {
                "table_id": table_id,
                "row_count": row_count,
                "col_count": col_count,
                "header_row_count": header_row_count,
                "method": method,
                "doc_id": doc_id,
                "page_number": page_number
            })

        # Build cells list (from table_json['cells'] or fallback to flattened_rows)
        cells = table_json.get("cells") or []
        if not cells:
            fr = table_json.get("flattened_rows") or []
            for ri, row in enumerate(fr):
                for ci, val in enumerate(row):
                    cells.append({
                        "id": f"{table_id}_r{ri}_c{ci}",
                        "r": ri, "c": ci, "rowspan": 1, "colspan": 1,
                        "bbox": None, "text": str(val), "raw_text": str(val), "confidence": 1.0
                    })

        # Write rows & cells
        with neo_driver.session() as sess:
            tx = sess.begin_transaction()
            for c in cells:
                r_idx = int(c.get("r", 0))
                tx.run(CREATE_ROW, {"table_id": table_id, "row_index": r_idx})
                tx.run(CREATE_CELL, {
                    "table_id": table_id,
                    "r": int(c.get("r", 0)),
                    "c": int(c.get("c", 0)),
                    "row_index": r_idx,
                    "rowspan": int(c.get("rowspan", 1)),
                    "colspan": int(c.get("colspan", 1)),
                    "text": c.get("text") or "",
                    "raw_text": c.get("raw_text") or "",
                    "confidence": float(c.get("confidence") or 0.0),
                    "bbox": c.get("bbox")
                })
            tx.commit()

        # Optional: extract entities from cell text via inference API
        texts = [ (c.get("text") or "") for c in cells ]
        ents_per_cell = call_entity_extraction(texts)
        if any(ents_per_cell):
            with neo_driver.session() as sess:
                tx = sess.begin_transaction()
                for idx, entity_list in enumerate(ents_per_cell):
                    if not entity_list:
                        continue
                    c = cells[idx]
                    for e in entity_list:
                        eid = e.get("id") or f"ENT::{(e.get('text') or '')[:100]}::{abs(hash(e.get('text') or ''))}"
                        label = e.get("text")
                        etype = e.get("type") or "entity"
                        conf = float(e.get("confidence", 1.0))
                        tx.run("MERGE (en:Entity {id:$eid}) SET en.label=$label, en.type=$etype", {"eid": eid, "label": label, "etype": etype})
                        tx.run("MATCH (c:Cell {table_id:$table_id, r:$r, c:$c}) MATCH (en:Entity {id:$eid}) MERGE (c)-[m:MENTIONS_ENTITY]->(en) SET m.confidence=$conf",
                               {"table_id": table_id, "r": int(c.get("r")), "c": int(c.get("c")), "eid": eid, "conf": conf})
                tx.commit()

    # Process chunks (text/table/image) for this file
    with pg_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT id, page_number, type, text, chunk_index, bbox, embedding_model, storage_path, thumbnail_path
            FROM chunks
            WHERE file_id = %s
            ORDER BY page_number, chunk_index
        """, (doc_id,))
        chunks = cur.fetchall()

    # Create Chunk nodes and Image nodes
    image_nodes = []  # collect for later cell linking
    with neo_driver.session() as sess:
        tx = sess.begin_transaction()
        for ck in chunks:
            tx.run(CREATE_CHUNK, {
                "chunk_id": str(ck["id"]),
                "type": ck.get("type"),
                "text": ck.get("text") or "",
                "page_number": int(ck.get("page_number") or 0),
                "chunk_index": int(ck.get("chunk_index") or 0),
                "embedding_model": ck.get("embedding_model"),
                "doc_id": doc_id
            })
            if ck.get("type") == "image":
                img_id = str(ck["id"])
                params = {
                    "img_id": img_id,
                    "file_id": doc_id,
                    "page_number": int(ck.get("page_number") or 0),
                    "storage_path": ck.get("storage_path"),
                    "thumbnail_path": ck.get("thumbnail_path"),
                    "bbox": ck.get("bbox"),
                    "width": None,
                    "height": None,
                    "ocr_text": ck.get("text") or "",
                    "caption": None,
                    "embedding_ref": None,
                    "chunk_id": str(ck["id"])
                }
                tx.run(CREATE_IMAGE, params)
                image_nodes.append({"img_id": img_id, "bbox": ck.get("bbox")})
        tx.commit()

    # Build a list of all cells for this document for bbox linking
    all_cells = []
    with pg_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT id, table_json FROM extracted_tables WHERE file_id = %s", (doc_id,))
        for row in cur.fetchall():
            tid = str(row["id"])
            tj = row.get("table_json") or {}
            for c in (tj.get("cells") or []):
                if not c:
                    continue
                all_cells.append({
                    "table_id": tid,
                    "r": int(c.get("r", 0)),
                    "c": int(c.get("c", 0)),
                    "bbox": c.get("bbox")
                })

    # Link chunks and images to cells by bbox IoU
    with neo_driver.session() as sess:
        tx = sess.begin_transaction()
        for ck in chunks:
            bbox = ck.get("bbox")
            if not bbox:
                continue
            # normalize if string
            if isinstance(bbox, str):
                try:
                    bbox = json.loads(bbox)
                except:
                    bbox = None
            if not bbox:
                continue
            candidates = []
            for c in all_cells:
                iou = bbox_iou(bbox, c.get("bbox"))
                if iou > 0.03:
                    candidates.append((iou, c))
            candidates = sorted(candidates, key=lambda x: -x[0])[:8]
            for score, c in candidates:
                tx.run(CREATE_CHUNK_REF_CELL, {
                    "chunk_id": str(ck["id"]),
                    "table_id": c["table_id"],
                    "r": int(c["r"]),
                    "c": int(c["c"]),
                    "file_id": doc_id,
                    "page_number": int(ck.get("page_number") or 0),
                    "bbox": bbox,
                    "score": float(score)
                })

        # link image nodes to cells
        for img in image_nodes:
            ib = img.get("bbox")
            if not ib:
                continue
            for c in all_cells:
                iou = bbox_iou(ib, c.get("bbox"))
                if iou > 0.03:
                    tx.run(CREATE_IMAGE_COVERS_CELL, {
                        "img_id": img["img_id"],
                        "table_id": c["table_id"],
                        "r": int(c["r"]),
                        "c": int(c["c"]),
                        "iou": float(iou)
                    })

        tx.commit()
# -----------------------   

# -----------------------
# Optional: Entity extraction for chunks and link to Entities
# -----------------------
def link_entities_from_chunks(chunks: List[Dict[str, Any]], neo_driver):
    """
    Call the inference API for chunks (if configured) and create Entity nodes
    plus MENTIONS_ENTITY relationships from Chunk -> Entity.
    """
    texts = [ (ck.get("text") or "") for ck in chunks ]
    ents_by_chunk = call_entity_extraction(texts)

    if not any(ents_by_chunk):
        return

    with neo_driver.session() as sess:
        tx = sess.begin_transaction()
        for ck, ents in zip(chunks, ents_by_chunk):
            if not ents:
                continue
            for e in ents:
                eid = e.get("id") or f"ENT::{(e.get('text') or '')[:120]}::{abs(hash(e.get('text') or ''))}"
                label = e.get("text") or ""
                etype = e.get("type") or "entity"
                conf = float(e.get("confidence", 1.0))
                # Merge entity node
                tx.run("MERGE (en:Entity {id:$eid}) SET en.label=$label, en.type=$etype", {"eid": eid, "label": label, "etype": etype})
                # Link chunk -> entity
                tx.run("""
                    MATCH (ck:Chunk {id:$chunk_id})
                    MATCH (en:Entity {id:$eid})
                    MERGE (ck)-[m:MENTIONS_ENTITY]->(en)
                    SET m.confidence = $conf
                """, {"chunk_id": str(ck.get("id")), "eid": eid, "conf": conf})
        tx.commit()


# -----------------------
# CLI / Entrypoint
# -----------------------
def main(limit: Optional[int] = None, offset: int = 0):
    """
    Main entry to build KG for files. This function is a thin wrapper.
    """
    build_kg_for_all_docs(limit=limit, offset=offset)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Build Neo4j KG from Postgres extracted artifacts.")
    parser.add_argument("--limit", type=int, help="Limit number of files to process")
    parser.add_argument("--offset", type=int, default=0, help="Offset for files")
    args = parser.parse_args()

    logger.info("Starting KG build (limit=%s offset=%s)", args.limit, args.offset)
    main(limit=args.limit, offset=args.offset)
    logger.info("KG build completed.")
