#!/usr/bin/env python3
"""
precompute_row_embeddings.py

Compute embeddings for each flattened row in extracted_tables and store them
into extracted_tables.row_embeddings as a JSON array of objects:
[
  {"row_index": 0, "embedding": [...], "text": "flattened row text"},
  ...
]

Behavior:
- By default the script scans `extracted_tables` for entries with NULL row_embeddings
  and computes embeddings for each row.
- You can limit to a single file by --file-id or to N tables via --limit.
- Embeddings are computed in batches and written back with minimal locking.

Environment variables:
- DATABASE_URL  (required)
- EMBEDDING_API_URL  (required)
- EMBEDDING_API_KEY  (required)
- BATCH_SIZE (optional, default 128)
- EMBEDDING_MODEL_NAME (optional, meta tag stored with rows)

Usage examples:
    # compute for all tables without row_embeddings
    export DATABASE_URL=postgresql://postgres:postgres@localhost:5432/kb
    export EMBEDDING_API_URL=https://embed.example/v1/embeddings
    export EMBEDDING_API_KEY=sk-...
    python precompute_row_embeddings.py

    # compute for a specific file (by files.id)
    python precompute_row_embeddings.py --file-id 3f9a... --limit 10

Notes:
- This script expects extracted_tables.flattened_rows to be present and to be a list of lists.
- Uses psycopg2; adjust the embedding API response normalization to match your API.
"""

import os
import json
import time
import logging
from typing import List, Dict, Any, Optional, Tuple

import psycopg2
import psycopg2.extras
import requests
import uuid
import argparse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("precompute_row_embeddings")

# Config from ENV
DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", "128"))
EMBEDDING_MODEL_NAME = os.environ.get("EMBEDDING_MODEL_NAME", "embed-default")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL environment variable is required")
if not EMBEDDING_API_URL or not EMBEDDING_API_KEY:
    raise RuntimeError("EMBEDDING_API_URL and EMBEDDING_API_KEY are required")

# -------------------------
# DB helpers
# -------------------------
def get_conn():
    return psycopg2.connect(DATABASE_URL)

def fetch_tables_missing_row_embeddings(conn, file_id: Optional[str]=None, limit: Optional[int]=None) -> List[Dict[str,Any]]:
    """
    Fetch extracted_tables rows where row_embeddings is NULL (not computed yet).
    Returns list of dict rows with fields: id, file_id, page_number, table_json
    """
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        if file_id:
            cur.execute("""
                SELECT id, file_id, page_number, table_json
                FROM extracted_tables
                WHERE file_id = %s
                ORDER BY created_at ASC
                LIMIT %s
            """, (file_id, limit or 1000))
        else:
            cur.execute("""
                SELECT id, file_id, page_number, table_json
                FROM extracted_tables
                WHERE row_embeddings IS NULL
                ORDER BY created_at ASC
                LIMIT %s
            """, (limit or 1000,))
        return cur.fetchall()

def update_table_row_embeddings(conn, table_id: str, row_embeddings: List[Dict[str,Any]]):
    """
    Update the extracted_tables.row_embeddings column for a table id.
    Stores JSONB array of {"row_index": int, "embedding": [...], "text": "...", "model": "..."}
    """
    with conn.cursor() as cur:
        cur.execute("""
            UPDATE extracted_tables
            SET row_embeddings = %s
            WHERE id = %s
        """, (json.dumps(row_embeddings), table_id))
        conn.commit()

# -------------------------
# Embedding API adapter
# -------------------------
def call_embedding_api(inputs: List[str]) -> List[List[float]]:
    """
    Call the embedding API with a list of input strings.
    Normalizes common response shapes to return list of embeddings (list of floats).
    """
    headers = {
        "Authorization": f"Bearer {EMBEDDING_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"input": inputs}
    resp = requests.post(EMBEDDING_API_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    j = resp.json()

    # Normalization: try common shapes
    # 1) {"data": [{"embedding": [...]}, ...]}
    if isinstance(j, dict) and "data" in j and isinstance(j["data"], list):
        embeddings = []
        for d in j["data"]:
            if isinstance(d, dict) and "embedding" in d:
                embeddings.append(d["embedding"])
            else:
                raise RuntimeError("Unexpected embedding item shape in 'data'")
        return embeddings

    # 2) {"embeddings": [...]}
    if isinstance(j, dict) and "embeddings" in j and isinstance(j["embeddings"], list):
        return j["embeddings"]

    # 3) list of items with "embedding"
    if isinstance(j, list) and j and isinstance(j[0], dict) and "embedding" in j[0]:
        return [item["embedding"] for item in j]

    # 4) single embedding in "embedding" key
    if isinstance(j, dict) and "embedding" in j and isinstance(j["embedding"], list):
        return [j["embedding"]]

    raise RuntimeError(f"Could not parse embedding response: {j}")

# -------------------------
# Utility: flatten a table_json rows -> list of strings
# -------------------------
def flattened_rows_to_texts(table_json: Dict[str,Any]) -> List[str]:
    """
    Accepts table_json and returns a list of flattened-row strings suitable for embedding.
    Uses flattened_rows (2D array). Joins cells with ' | ' to preserve column boundaries.
    """
    fr = table_json.get("flattened_rows") or []
    texts = []
    for r in fr:
        # coerce each cell to string and strip
        row_cells = [ ("" if c is None else str(c)).strip() for c in r ]
        texts.append(" | ".join(row_cells))
    return texts

# -------------------------
# Main orchestration
# -------------------------
def process_tables(file_id: Optional[str]=None, limit: Optional[int]=None):
    conn = get_conn()
    try:
        tables = fetch_tables_missing_row_embeddings(conn, file_id=file_id, limit=limit)
        logger.info("Found %d tables to process", len(tables))
        for t in tables:
            table_id = str(t["id"])
            logger.info("Processing table id=%s (file=%s page=%s)", table_id, t["file_id"], t["page_number"])
            table_json = t.get("table_json") or {}
            row_texts = flattened_rows_to_texts(table_json)
            if not row_texts:
                logger.info("No rows found for table %s — writing empty embeddings marker", table_id)
                update_table_row_embeddings(conn, table_id, [])
                continue

            # Compute embeddings in batches
            embeddings_for_rows = [None] * len(row_texts)
            for i in range(0, len(row_texts), BATCH_SIZE):
                batch_texts = row_texts[i:i+BATCH_SIZE]
                logger.info("Embedding batch rows %d..%d for table %s", i, i+len(batch_texts)-1, table_id)
                try:
                    batch_embeddings = call_embedding_api(batch_texts)
                except Exception as exc:
                    logger.exception("Embedding API failed for table %s: %s", table_id, exc)
                    # retry once after slight backoff
                    time.sleep(2.0)
                    batch_embeddings = call_embedding_api(batch_texts)

                # ensure response length matches
                if len(batch_embeddings) != len(batch_texts):
                    raise RuntimeError("Embedding API returned unexpected number of embeddings")

                for j, emb in enumerate(batch_embeddings):
                    embeddings_for_rows[i+j] = emb

            # prepare JSON payload for row_embeddings column
            row_embeddings_payload = []
            for idx, emb in enumerate(embeddings_for_rows):
                row_embeddings_payload.append({
                    "row_index": idx,
                    "embedding": emb,
                    "text": row_texts[idx],
                    "model": EMBEDDING_MODEL_NAME,
                    "computed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                })

            # write to DB
            update_table_row_embeddings(conn, table_id, row_embeddings_payload)
            logger.info("Wrote %d row embeddings for table %s", len(row_embeddings_payload), table_id)

    finally:
        conn.close()

# -------------------------
# CLI
# -------------------------
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--file-id", help="Process only tables belonging to this files.id (UUID or text)")
    ap.add_argument("--limit", type=int, help="Maximum number of tables to process (default 1000)", default=1000)
    args = ap.parse_args()

    process_tables(file_id=args.file_id, limit=args.limit)
# ---------------------------------------------
# END OF FILE
# ---------------------------------------------