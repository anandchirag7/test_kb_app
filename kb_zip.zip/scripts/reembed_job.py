#!/usr/bin/env python3
"""
reembed_job.py

Periodic maintenance job that:
- Reads chunks from Postgres
- Recomputes embeddings using your embedding API
- Updates chunks.embedding in-place with minimal downtime
- Safe batching + transactional updates
- Can run daily / hourly via Cron, Airflow, Prefect, etc.

Environment Variables:
    DATABASE_URL
    EMBEDDING_API_URL
    EMBEDDING_API_KEY
    BATCH_SIZE       (default 128)
"""

import os
import json
import time
import logging
from typing import List, Dict, Any

import psycopg2
import psycopg2.extras
import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("reembed_job")

DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", "128"))

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is required")


# ---------------------------------------------
# Embedding API call
# ---------------------------------------------
def call_embedding_api(texts: List[str]) -> List[List[float]]:
    headers = {"Authorization": f"Bearer {EMBEDDING_API_KEY}"} if EMBEDDING_API_KEY else {}
    resp = requests.post(
        EMBEDDING_API_URL,
        headers=headers,
        json={"input": texts},
        timeout=60
    )
    resp.raise_for_status()
    j = resp.json()

    if isinstance(j, dict) and "data" in j:
        return [d["embedding"] for d in j["data"]]

    if isinstance(j, list) and isinstance(j[0], dict) and "embedding" in j[0]:
        return [d["embedding"] for d in j]

    raise RuntimeError(f"Unexpected embedding API format: {j}")


# ---------------------------------------------
# Database helpers
# ---------------------------------------------
def get_connection():
    return psycopg2.connect(DATABASE_URL)


def fetch_chunks_pending_reembed(conn, batch_size: int):
    """Return list of chunk rows that need vector refresh."""
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT id, text
            FROM chunks
            WHERE embedding IS NOT NULL
            ORDER BY created_at ASC
            LIMIT %s
        """, (batch_size,))
        return cur.fetchall()


def update_embeddings(conn, updates: List[Dict[str, Any]]):
    """Perform efficient batched updates."""
    with conn.cursor() as cur:
        for u in updates:
            cur.execute("""
                UPDATE chunks
                SET embedding = %s,
                    embedding_model = %s
                WHERE id = %s
            """, (u["embedding"], u["embedding_model"], u["id"]))
        conn.commit()


# ---------------------------------------------
# MAIN LOOP
# ---------------------------------------------
def run_once():
    conn = get_connection()
    try:
        while True:
            rows = fetch_chunks_pending_reembed(conn, BATCH_SIZE)
            if not rows:
                logger.info("No chunks to re-embed. Done.")
                break

            texts = [r["text"] or "" for r in rows]
            new_embeddings = call_embedding_api(texts)

            updates = []
            for r, emb in zip(rows, new_embeddings):
                updates.append({
                    "id": r["id"],
                    "embedding": emb,
                    "embedding_model": "embed-default"
                })

            update_embeddings(conn, updates)
            logger.info(f"Re-embedded {len(rows)} chunks...")

    finally:
        conn.close()


if __name__ == "__main__":
    logger.info("Starting re-embedding job...")
    run_once()
    logger.info("Re-embedding job completed.")
    logger.info("Starting re-embedding job...")
    run_once()
    logger.info("Re-embedding job completed.")  