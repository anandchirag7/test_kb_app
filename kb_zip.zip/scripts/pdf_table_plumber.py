#!/usr/bin/env python3
"""
pdf_table_plumber.py — Standalone but fully compatible table extractor using pdfplumber.

Outputs table_json format used by ingestion and KG builder.

Usage:
    python pdf_table_plumber.py --pdf input.pdf --page 1
"""

import argparse
import json
import logging
from typing import List, Dict, Any

import pdfplumber

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pdf_table_plumber")


def _looks_like_number(s: str) -> bool:
    if not s:
        return False
    try:
        float(str(s).replace(",", "").strip())
        return True
    except Exception:
        return False


def extract_with_pdfplumber(pdf_path: str, page_number: int) -> List[Dict[str, Any]]:
    """
    Extract tables from a PDF using pdfplumber's table detection.
    Returns a list of table_json-like objects.
    """
    results = []

    with pdfplumber.open(pdf_path) as pdf:
        if page_number < 1 or page_number > len(pdf.pages):
            raise ValueError(f"Invalid page_number={page_number}")

        p = pdf.pages[page_number - 1]

        try:
            tables = p.find_tables()
        except Exception as e:
            logger.error("pdfplumber find_tables failed: %s", e)
            return []

        for t in tables:
            try:
                matrix = t.extract()
                if not matrix:
                    continue

                rows = [[(c or "").strip() for c in r] for r in matrix]

                # Attempt to gather cell-level bbox + rowspan/colspan when available
                cells = []
                if hasattr(t, "cells") and t.cells:
                    for idx, cell in enumerate(t.cells):
                        raw = (cell.get("text") or "").strip()
                        bbox = [
                            cell.get("x0"),
                            cell.get("top"),
                            cell.get("x1"),
                            cell.get("bottom"),
                        ]
                        r = int(cell.get("row", 0))
                        c = int(cell.get("col", 0))
                        rs = int(cell.get("rowspan", 1))
                        cs = int(cell.get("colspan", 1))

                        cells.append({
                            "id": f"c{idx+1}",
                            "r": r,
                            "c": c,
                            "rowspan": rs,
                            "colspan": cs,
                            "bbox": bbox,
                            "text": raw,
                            "raw_text": raw,
                            "confidence": 1.0,
                            "type": "number" if _looks_like_number(raw) else "string",
                        })

                table_json = {
                    "headers": rows[:1] if rows else [],
                    "row_count": len(rows),
                    "col_count": max((len(r) for r in rows), default=0),
                    "header_row_count": 1 if rows else 0,
                    "cells": cells,
                    "flattened_rows": rows,
                    "notes": "extracted with pdfplumber",
                    "origin": {
                        "page_number": page_number,
                        "method": "pdfplumber"
                    },
                }

                results.append(table_json)

            except Exception as e:
                logger.warning("Failed extracting table: %s", e)

    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--page", required=True, type=int)
    args = ap.parse_args()

    tables = extract_with_pdfplumber(args.pdf, args.page)
    print(json.dumps(tables, indent=2))
