#!/usr/bin/env python3
"""
table_extractor.py — Unified Table Extraction Orchestrator

This module provides a consistent interface to extract tables from PDFs
using multiple extractors:

Priority Order:
1. Camelot (lattice → stream)
2. pdfplumber
3. tabula-py
4. Image-based extraction (OpenCV + OCR) — via table_image_parser.py

Each extractor returns:
[
    {
        "rows": [["col1", "col2", ...], ...],
        "cells": [
            {"id": "...", "r": 0, "c": 0, "rowspan": 1, "colspan": 1,
             "bbox": [...], "text": "...", "raw_text": "...",
             "confidence": 1.0, "type": "string|number"},
            ...
        ],
        "method": "camelot|pdfplumber|tabula|image"
    },
    ...
]

This file is used by the ingestion pipeline and can be used independently.
"""

import os
import logging
import json

try:
    import camelot
except Exception:
    camelot = None

try:
    import pdfplumber
except Exception:
    pdfplumber = None

try:
    import tabula
except Exception:
    tabula = None

from PIL import Image
import pytesseract

# For image table extraction fallback
try:
    from scripts.table_image_parser import parse_page_image
except Exception:
    parse_page_image = None

logger = logging.getLogger("table_extractor")
logging.basicConfig(level=logging.INFO)


# -----------------------------------------------------
# Helpers
# -----------------------------------------------------
def _looks_like_number(s):
    if not s:
        return False
    try:
        float(str(s).replace(",", "").strip())
        return True
    except:
        return False


# -----------------------------------------------------
# Extractor Implementations
# -----------------------------------------------------

def extract_camelot(pdf_path: str, page_number: int):
    """Use Camelot lattice → stream"""
    if camelot is None:
        return []

    out = []
    try:
        # LATTICE
        tables = camelot.read_pdf(pdf_path, pages=str(page_number), flavor="lattice")
        if not tables or len(tables) == 0:
            # STREAM fallback
            tables = camelot.read_pdf(pdf_path, pages=str(page_number), flavor="stream")

        for t in tables:
            try:
                df = t.df.fillna("").astype(str)
                rows = df.values.tolist()
                out.append({"rows": rows, "cells": [], "method": "camelot"})
            except Exception as e:
                logger.debug("Camelot extraction error: %s", e)

    except Exception as e:
        logger.debug("Camelot failed: %s", e)

    return out


def extract_pdfplumber(pdf_path: str, page_number: int):
    """Use pdfplumber table detection"""
    if pdfplumber is None:
        return []

    out = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            page = pdf.pages[page_number - 1]

            try:
                tables = page.find_tables()
            except Exception:
                tables = []

            for t in tables:
                try:
                    matrix = t.extract()
                    rows = [[(c or "").strip() for c in r] for r in matrix]
                    cells = []

                    # pdfplumber sometimes provides geometry for each cell
                    if hasattr(t, "cells") and t.cells:
                        for idx, cell in enumerate(t.cells):
                            txt = (cell.get("text") or "").strip()
                            bbox = [
                                cell.get("x0"),
                                cell.get("top"),
                                cell.get("x1"),
                                cell.get("bottom"),
                            ]
                            cells.append({
                                "id": f"c{idx+1}",
                                "r": cell.get("row", 0),
                                "c": cell.get("col", 0),
                                "rowspan": int(cell.get("rowspan", 1)),
                                "colspan": int(cell.get("colspan", 1)),
                                "bbox": bbox,
                                "text": txt,
                                "raw_text": txt,
                                "confidence": 1.0,
                                "type": "number" if _looks_like_number(txt) else "string",
                            })

                    out.append({"rows": rows, "cells": cells, "method": "pdfplumber"})
                except Exception as e:
                    logger.debug("pdfplumber extraction error: %s", e)

    except Exception as e:
        logger.debug("pdfplumber failed: %s", e)

    return out


def extract_tabula(pdf_path: str, page_number: int):
    """Use tabula-py (Java required)"""
    if tabula is None:
        return []

    out = []
    try:
        dfs = tabula.read_pdf(
            pdf_path,
            pages=str(page_number),
            multiple_tables=True,
            guess=True,
            lattice=True,
        )
        for df in dfs:
            try:
                rows = df.fillna("").astype(str).values.tolist()
                out.append({"rows": rows, "cells": [], "method": "tabula"})
            except Exception:
                continue

    except Exception as e:
        logger.debug("tabula failed: %s", e)

    return out


def extract_image_parser(pdf_path: str, page_number: int):
    """Fallback image-based table parsing (OpenCV + OCR + heuristics)"""
    if pdfplumber is None or parse_page_image is None:
        return []

    out = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            p = pdf.pages[page_number - 1]
            pil = p.to_image(resolution=300).original
            results = parse_page_image(
                pil, lang="eng", detect_min_area=2000
            )
            for r in results:
                out.append({
                    "rows": r.get("flattened_rows", []),
                    "cells": r.get("cells", []),
                    "method": "image",
                })

    except Exception as e:
        logger.debug("image parser failed: %s", e)

    return out


# -----------------------------------------------------
# MAIN ORCHESTRATOR
# -----------------------------------------------------

DEFAULT_EXTRACTOR_ORDER = ["camelot", "pdfplumber", "tabula", "image"]

EXTRACTOR_FUNCS = {
    "camelot": extract_camelot,
    "pdfplumber": extract_pdfplumber,
    "tabula": extract_tabula,
    "image": extract_image_parser,
}


def extract_tables(pdf_path: str, page_number: int, preference=None):
    """
    Extract tables following priority or custom preference.

    preference example:
        ["pdfplumber", "camelot", "image"]

    Returns immediately when the FIRST extractor returns results.
    """

    order = preference or DEFAULT_EXTRACTOR_ORDER

    for method in order:
        fn = EXTRACTOR_FUNCS.get(method)
        if not fn:
            continue
        try:
            tables = fn(pdf_path, page_number)
            if tables:
                logger.info(f"[Page {page_number}] Extractor success: {method}")
                return tables
        except Exception as e:
            logger.debug("%s extractor failed: %s", method, e)

    logger.info(f"[Page {page_number}] No tables found by any extractor.")
    return []


# -----------------------------------------------------
# CLI
# -----------------------------------------------------

if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--page", required=True, type=int)
    ap.add_argument("--extractors", help="comma-separated preference list")

    args = ap.parse_args()
    pref = (
        [p.strip() for p in args.extractors.split(",")]
        if args.extractors
        else DEFAULT_EXTRACTOR_ORDER
    )

    result = extract_tables(args.pdf, args.page, preference=pref)
    print(json.dumps(result, indent=2))
