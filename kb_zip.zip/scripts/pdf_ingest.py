#!/usr/bin/env python3
"""
pdf_ingest.py — FINAL INGESTION WORKER

Features:
- Text extraction with pdfplumber + OCR fallback
- Image extraction from PDF (inline images, page images)
- Thumbnail generation for images
- Storage to STORAGE_PREFIX/<file_id>/
- Table extraction using pdfplumber (basic)
- Chunk creation (text, table, image)
- Embedding API batching
- DB insertion (chunks + extracted_tables)
- Works with KG builder (neo4j_build_kg.py)

Requires ENV:
DATABASE_URL
EMBEDDING_API_URL
EMBEDDING_API_KEY
STORAGE_PREFIX        (default: /mnt/data/storage)
IMAGE_DPI             (default: 200)
THUMB_MAX_SIZE        (default: 400)
"""

import os
import json
import uuid
import logging
import argparse
from typing import List

import requests
import psycopg2
import psycopg2.extras

import pdfplumber
from PIL import Image
import pytesseract

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pdf_ingest")

# -----------------------------
# ENV CONFIG
# -----------------------------
DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")
STORAGE_PREFIX = os.environ.get("STORAGE_PREFIX", "/mnt/data/storage")
IMAGE_DPI = int(os.environ.get("IMAGE_DPI", "200"))
THUMB_MAX_SIZE = int(os.environ.get("THUMB_MAX_SIZE", "400"))

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL not set")

# -----------------------------
# HELPERS
# -----------------------------
def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)
    return path

def save_image(img: Image.Image, dest: str):
    ensure_dir(os.path.dirname(dest))
    img.save(dest, format="PNG", optimize=True)
    return dest

def make_thumb(img: Image.Image, max_size: int = 400):
    im = img.copy()
    im.thumbnail((max_size, max_size))
    return im

def sha256_of_file(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def call_embedding_api(texts: List[str]):
    if not EMBEDDING_API_URL or not EMBEDDING_API_KEY:
        raise RuntimeError("Embedding API not configured.")
    headers = {
        "Authorization": f"Bearer {EMBEDDING_API_KEY}",
        "Content-Type": "application/json"
    }
    resp = requests.post(
        EMBEDDING_API_URL,
        headers=headers,
        json={"input": texts},
        timeout=60
    )
    resp.raise_for_status()
    j = resp.json()

    # Normalize various API formats
    if isinstance(j, dict) and "data" in j:
        return [d.get("embedding") for d in j["data"]]
    if isinstance(j, dict) and "embeddings" in j:
        return j["embeddings"]
    if isinstance(j, list) and isinstance(j[0], dict) and "embedding" in j[0]:
        return [d["embedding"] for d in j]
    raise RuntimeError("Unknown embedding API response")

def insert_chunks(conn, chunks):
    with conn.cursor() as cur:
        for c in chunks:
            cur.execute("""
                INSERT INTO chunks (
                    id, file_id, page_number, type, chunk_index,
                    bbox, text, storage_path, thumbnail_path,
                    embedding, embedding_model, detected_entities,
                    language, chunk_len_tokens, confidence, created_at
                )
                VALUES (
                    %s,%s,%s,%s,%s,
                    %s::jsonb,%s,%s,%s,
                    %s,%s,%s::jsonb,
                    %s,%s,%s,now()
                )
            """, (
                c.get("id") or str(uuid.uuid4()),
                c["file_id"],
                c["page_number"],
                c["type"],
                c["chunk_index"],
                json.dumps(c["bbox"]) if c["bbox"] else None,
                c["text"],
                c.get("storage_path"),
                c.get("thumbnail_path"),
                c["embedding"],
                c["embedding_model"],
                json.dumps(c.get("detected_entities") or {}),
                c["language"],
                c["chunk_len_tokens"],
                c["confidence"]
            ))
        conn.commit()

# -----------------------------
# MAIN INGEST FUNCTION
# -----------------------------
def ingest_pdf(path: str):
    filesize = os.path.getsize(path)
    content_hash = sha256_of_file(path)
    filename = os.path.basename(path)

    conn = psycopg2.connect(DATABASE_URL)

    # Insert or update `files` record
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO files (filename, storage_path, filesize_bytes, content_hash, source)
            VALUES (%s,%s,%s,%s,%s)
            ON CONFLICT (content_hash)
                DO UPDATE SET filename=EXCLUDED.filename
            RETURNING id
        """, (filename, path, filesize, content_hash, "uploader"))
        file_id = cur.fetchone()[0]
        conn.commit()

    logger.info(f"File ID: {file_id}")

    chunks = []
    table_rows = []
    chunk_index = 0

    with pdfplumber.open(path) as pdf:
        for pagenum, page in enumerate(pdf.pages, start=1):
            # ------------------------------------
            # TEXT EXTRACTION
            # ------------------------------------
            text = page.extract_text() or ""
            if len(text.strip()) < 10:
                # fallback OCR
                pil_page = page.to_image(resolution=IMAGE_DPI).original
                try:
                    text = pytesseract.image_to_string(pil_page)
                except:
                    pass

            if text.strip():
                chunks.append({
                    "id": str(uuid.uuid4()),
                    "file_id": file_id,
                    "page_number": pagenum,
                    "type": "text",
                    "chunk_index": chunk_index,
                    "bbox": None,
                    "text": text,
                    "storage_path": None,
                    "thumbnail_path": None,
                    "embedding": None,
                    "embedding_model": None,
                    "detected_entities": {},
                    "language": "en",
                    "chunk_len_tokens": max(1, len(text)//4),
                    "confidence": 0.9
                })
                chunk_index += 1

            # ------------------------------------
            # SAVE PAGE IMAGE
            # ------------------------------------
            try:
                page_img = page.to_image(resolution=IMAGE_DPI).original
                store_dir = os.path.join(STORAGE_PREFIX, str(file_id), "pages")
                ensure_dir(store_dir)
                page_img_path = os.path.join(store_dir, f"page_{pagenum}.png")
                save_image(page_img, page_img_path)
            except:
                page_img_path = None

            # ------------------------------------
            # INLINE IMAGES
            # ------------------------------------
            try:
                images = page.images or []
            except:
                images = []

            for idx, imeta in enumerate(images):
                try:
                    x0, top, x1, bottom = imeta["x0"], imeta["top"], imeta["x1"], imeta["bottom"]
                    crop_page = page.within_bbox((x0, top, x1, bottom))
                    pil_crop = crop_page.to_image(resolution=IMAGE_DPI).original
                except:
                    pil_crop = page.to_image(resolution=IMAGE_DPI).original

                try:
                    caption = pytesseract.image_to_string(pil_crop)
                except:
                    caption = ""

                img_dir = os.path.join(STORAGE_PREFIX, str(file_id), "images")
                ensure_dir(img_dir)

                fname = f"page_{pagenum}_img_{idx}.png"
                fpath = os.path.join(img_dir, fname)
                tpath = os.path.join(img_dir, f"thumb_{fname}")

                try:
                    save_image(pil_crop, fpath)
                    thumb = make_thumb(pil_crop, THUMB_MAX_SIZE)
                    save_image(thumb, tpath)
                except:
                    fpath = None
                    tpath = None

                chunks.append({
                    "id": str(uuid.uuid4()),
                    "file_id": file_id,
                    "page_number": pagenum,
                    "type": "image",
                    "chunk_index": chunk_index,
                    "bbox": [x0, top, x1, bottom],
                    "text": caption or "",
                    "storage_path": fpath,
                    "thumbnail_path": tpath,
                    "embedding": None,
                    "embedding_model": None,
                    "detected_entities": {},
                    "language": "en",
                    "chunk_len_tokens": max(1, len(caption)//4),
                    "confidence": 0.78
                })
                chunk_index += 1

            # ------------------------------------
            # TABLE EXTRACTION (pdfplumber basic)
            # ------------------------------------
            try:
                pdf_tables = page.find_tables()
            except:
                pdf_tables = []

            for t in pdf_tables:
                try:
                    matrix = t.extract()
                    rows_csv = "\n".join([",".join([str(x) for x in r]) for r in matrix])
                    table_json = {
                        "flattened_rows": matrix,
                        "headers": matrix[0] if matrix else [],
                        "row_count": len(matrix),
                        "col_count": max((len(r) for r in matrix), default=0),
                        "origin": {"page_number": pagenum, "method": "pdfplumber"},
                    }
                    table_rows.append((pagenum, table_json))

                    chunks.append({
                        "id": str(uuid.uuid4()),
                        "file_id": file_id,
                        "page_number": pagenum,
                        "type": "table",
                        "chunk_index": chunk_index,
                        "bbox": None,
                        "text": rows_csv,
                        "storage_path": None,
                        "thumbnail_path": None,
                        "embedding": None,
                        "embedding_model": None,
                        "detected_entities": {},
                        "language": "en",
                        "chunk_len_tokens": max(1, len(rows_csv)//4),
                        "confidence": 0.95
                    })
                    chunk_index += 1
                except:
                    pass

    # ----------------------------------------
    # EMBEDDING
    # ----------------------------------------
    texts = [c["text"] for c in chunks]
    embeddings = []
    for i in range(0, len(texts), 64):
        batch = texts[i:i+64]
        embeddings.extend(call_embedding_api(batch))

    for c, emb in zip(chunks, embeddings):
        c["embedding"] = emb
        c["embedding_model"] = "embed-default"

    # ----------------------------------------
    # DB INSERT
    # ----------------------------------------
    insert_chunks(conn, chunks)

    with conn.cursor() as cur:
        for pn, tj in table_rows:
            cur.execute("""
                INSERT INTO extracted_tables (file_id, page_number, table_json, normalized_csv)
                VALUES (%s,%s,%s,%s)
            """, (
                file_id,
                pn,
                json.dumps(tj),
                "\n".join([",".join(r) for r in tj["flattened_rows"]])
            ))
        conn.commit()

    conn.close()
    logger.info(f"Ingestion done: {path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", required=True)
    args = ap.parse_args()
    ingest_pdf(args.pdf)
