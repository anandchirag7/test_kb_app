#!/usr/bin/env python3
"""
pdf_table_tabula.py

Standalone wrapper for tabula-py based table extraction (Java required).

Produces `table_json` objects compatible with the ingestion pipeline:
{
  "headers": [...],
  "row_count": N,
  "col_count": M,
  "header_row_count": H,
  "cells": [...],              # optional, usually empty from tabula
  "flattened_rows": [[...],...],
  "origin": {"page_number": p, "method": "tabula"}
}

Usage:
    python pdf_table_tabula.py --pdf input.pdf --page 1 --lattice
"""

import argparse
import logging
import json
from typing import List, Dict, Any

try:
    from tabula import tabula
except Exception as e:
    tabula = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pdf_table_tabula")


def extract_with_tabula(pdf_path: str, page_number: int, lattice: bool = True, guess: bool = True) -> List[Dict[str, Any]]:
    """
    Extract tables using tabula-py. Returns a list of table_json objects.

    Note: tabula-py uses a Java subprocess. Ensure Java is installed.
    """
    if tabula is None:
        raise RuntimeError("tabula-py is not installed in this environment")

    pagespec = str(page_number)
    try:
        # read_pdf returns list of DataFrames when multiple_tables=True
        dfs = tabula.read_pdf(pdf_path, pages=pagespec, multiple_tables=True, lattice=lattice, guess=guess)
    except Exception as exc:
        logger.error("tabula.read_pdf failed: %s", exc)
        return []

    results = []
    for df in dfs:
        try:
            # sanitize dataframe: convert NaN to empty strings and cast to str
            df = df.fillna("").astype(str)
            rows = df.values.tolist()
            flattened = [[(c or "").strip() for c in r] for r in rows]
            table_json = {
                "headers": flattened[:1] if flattened else [],
                "row_count": len(flattened),
                "col_count": max((len(r) for r in flattened), default=0),
                "header_row_count": 1 if flattened else 0,
                "cells": [],  # tabula usually doesn't provide cell-level bbox info
                "flattened_rows": flattened,
                "origin": {"page_number": page_number, "method": "tabula"}
            }
            results.append(table_json)
        except Exception as e:
            logger.warning("Failed to convert tabula DataFrame to table_json: %s", e)
            continue

    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", required=True, help="Path to PDF")
    ap.add_argument("--page", required=True, type=int, help="Page number (1-indexed)")
    ap.add_argument("--lattice", action="store_true", default=False, help="Use lattice mode (table with lines)")
    ap.add_argument("--guess", action="store_true", default=True, help="Use guess mode for table detection")
    args = ap.parse_args()

    try:
        tables = extract_with_tabula(args.pdf, args.page, lattice=args.lattice, guess=args.guess)
        print(json.dumps(tables, indent=2))
    except Exception as exc:
        logger.error("Extraction failed: %s", exc)
        raise
