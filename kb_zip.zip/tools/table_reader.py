"""
table_reader.py

Core logic for:
- SQL-like row selection on extracted_tables (SELECT col WHERE col=value)
- Fuzzy row search using row_embeddings + cosine similarity
- Provenance lookup helpers
- Fuzzy column name matching (optional)
"""

import psycopg2
import psycopg2.extras
import numpy as np
import os
from typing import List, Dict, Any, Optional
import json
import requests


DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")


# ---------------------------------------------------
# Embedding helper
# ---------------------------------------------------
def embed(texts: List[str]) -> List[List[float]]:
    headers = {}
    if EMBEDDING_API_KEY:
        headers["Authorization"] = f"Bearer {EMBEDDING_API_KEY}"

    resp = requests.post(
        EMBEDDING_API_URL,
        headers=headers,
        json={"input": texts},
        timeout=60
    )
    resp.raise_for_status()
    j = resp.json()

    if isinstance(j, dict) and "data" in j:
        return [d["embedding"] for d in j["data"]]
    if isinstance(j, list) and isinstance(j[0], dict) and "embedding" in j[0]:
        return [d["embedding"] for d in j]
    if isinstance(j, dict) and "embeddings" in j:
        return j["embeddings"]

    raise RuntimeError(f"Unknown embedding response format: {j}")


# ---------------------------------------------------
# SQL-like table row filtering
# ---------------------------------------------------
def query_table(table_id: str, where_col: str, where_val: str) -> List[List[str]]:
    conn = psycopg2.connect(DATABASE_URL)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT table_json
                FROM extracted_tables
                WHERE id = %s
            """, (table_id,))
            row = cur.fetchone()
            if not row:
                return []

            tj = row["table_json"] or {}
            fr = tj.get("flattened_rows") or []
            headers = tj.get("headers") or fr[:1]
            header = headers[0] if headers else []

            col_map = {h.strip().lower(): idx for idx, h in enumerate(header)}
            idx = col_map.get(where_col.lower())
            if idx is None:
                return []

            out = []
            for r in fr:
                if idx < len(r) and str(r[idx]).strip().lower() == where_val.lower():
                    out.append(r)
            return out

    finally:
        conn.close()


# ---------------------------------------------------
# Fuzzy row search (row_embeddings)
# ---------------------------------------------------
def cosine(a: List[float], b: List[float]) -> float:
    a = np.array(a); b = np.array(b)
    denom = np.linalg.norm(a) * np.linalg.norm(b) + 1e-9
    return float(a @ b / denom)


def fuzzy_query(table_id: str, query: str, top_k: int = 5):
    conn = psycopg2.connect(DATABASE_URL)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT row_embeddings
                FROM extracted_tables
                WHERE id = %s
            """, (table_id,))
            row = cur.fetchone()
            if not row:
                return []

            rows_emb = row["row_embeddings"] or []
            if not rows_emb:
                return []

            query_emb = embed([query])[0]

            scored = []
            for re in rows_emb:
                s = cosine(query_emb, re["embedding"])
                scored.append((s, re))

            scored = sorted(scored, key=lambda x: -x[0])[:top_k]
            return [{"score": s, "row": r} for s, r in scored]

    finally:
        conn.close()


# ---------------------------------------------------
# Provenance utilities
# ---------------------------------------------------
def cell_provenance(table_id: str, r: int, c: int) -> Optional[Dict[str, Any]]:
    conn = psycopg2.connect(DATABASE_URL)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT table_json
                FROM extracted_tables
                WHERE id = %s
            """, (table_id,))
            row = cur.fetchone()
            if not row:
                return None

            cells = (row["table_json"] or {}).get("cells") or []
            for ce in cells:
                if ce.get("r") == r and ce.get("c") == c:
                    return ce
            return None
    finally:
        conn.close()
