"""
provenance_utils.py

Utility functions for mapping:
- chunks → cells (IoU-based)
- images → cells (IoU-based)
- cell/page/image provenance extraction

These utilities are shared by the table_reader API and can be used
directly by your UI to highlight relevant regions in the PDF images.
"""

from typing import List, Dict, Any, Optional
import json
import math


# ---------------------------------------------------------
# BBOX helpers
# ---------------------------------------------------------
def clean_bbox(b):
    """Normalize bbox into [x0, y0, x1, y1] floats."""
    if b is None:
        return None
    if isinstance(b, str):
        try:
            b = json.loads(b)
        except:
            return None
    if not isinstance(b, (list, tuple)) or len(b) != 4:
        return None
    try:
        x0, y0, x1, y1 = map(float, b)
        if x1 > x0 and y1 > y0:
            return [x0, y0, x1, y1]
    except:
        return None
    return None


def bbox_iou(a: List[float], b: List[float]) -> float:
    """Compute IoU between two bboxes."""
    if not a or not b:
        return 0.0

    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b

    ix0 = max(ax0, bx0)
    iy0 = max(ay0, by0)
    ix1 = min(ax1, bx1)
    iy1 = min(ay1, by1)

    iw = max(0.0, ix1 - ix0)
    ih = max(0.0, iy1 - iy0)
    inter = iw * ih

    area_a = max(1e-9, (ax1 - ax0) * (ay1 - ay0))
    area_b = max(1e-9, (bx1 - bx0) * (by1 - by0))
    denom = area_a + area_b - inter
    if denom <= 0:
        return 0.0

    return inter / denom


# ---------------------------------------------------------
# Map a chunk → best cell(s)
# ---------------------------------------------------------
def chunk_to_cells(chunk_bbox, cell_list, threshold=0.05):
    """
    Return cells with IoU > threshold, sorted by IoU descending.
    """
    cb = clean_bbox(chunk_bbox)
    if not cb:
        return []

    scores = []
    for ce in cell_list:
        bbox = clean_bbox(ce.get("bbox"))
        if not bbox:
            continue
        iou = bbox_iou(cb, bbox)
        if iou > threshold:
            scores.append((iou, ce))

    return sorted(scores, key=lambda x: -x[0])


# ---------------------------------------------------------
# Map an image → best cell(s)
# ---------------------------------------------------------
def image_to_cells(img_bbox, cell_list, threshold=0.05):
    """
    Same logic as chunk_to_cells but for images.
    """
    return chunk_to_cells(img_bbox, cell_list, threshold)


# ---------------------------------------------------------
# Build a provenance map for UI
# ---------------------------------------------------------
def build_provenance_response(page_number, bbox, storage_path=None, thumbnail_path=None):
    """
    Return a provenance dict suitable for UI display:
    {
        "page_number": 1,
        "bbox": [x0,y0,x1,y1],
        "storage_path": "...",
        "thumbnail_path": "..."
    }
    """
    return {
        "page_number": page_number,
        "bbox": bbox,
        "storage_path": storage_path,
        "thumbnail_path": thumbnail_path,
    }


# ---------------------------------------------------------
# Merge multiple provenance hits (chunk + image + cell)
# ---------------------------------------------------------
def merge_provenance(*items):
    """
    Merge provenance dicts. Later items override earlier if keys conflict.
    """
    out = {}
    for it in items:
        if not it:
            continue
        for k, v in it.items():
            if v is not None:
                out[k] = v
    return out
# ---------------------------------------------
# END OF FILE