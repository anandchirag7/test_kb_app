# KB Ingest — Architecture & Quickstart

This repository contains the PDF ingestion + table extraction + vector KB + KG builder system.

## What is included
- ingestion worker: `scripts/pdf_ingest.py`
- table extraction orchestrator: `scripts/table_extractor.py`
- image table parser: `scripts/table_image_parser.py`
- KG builder: `scripts/neo4j_build_kg.py`
- utilities, precompute and reembed job scripts
- Postgres schema: `migrations/flyway/V1__create_kb_schema.sql`
- docker-compose for local dev

## Quickstart (local with system deps installed)
1. Install system dependencies:
   - Debian/Ubuntu example:
     ```bash
     sudo apt update
     sudo apt install -y python3-pip python3-venv default-jre tesseract-ocr ghostscript libxml2-dev libxslt1-dev poppler-utils
     ```
   - For Camelot: install TK/GTK as needed and Ghostscript.
   - For tabula-py: Java (JRE/JDK) is required.

2. Create Python environment & install:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
