#!/usr/bin/env python3
"""
table_reader_api/app.py (updated)

Adds:
 - /search-all-pgvector  : pgvector-backed ANN search (fast & scalable)
 - /kg-reason-template   : allowlisted Cypher template execution (hardened)
Keeps existing endpoints (/search-all, /fuzzy-all-tables, /compare-docs).
"""

import os
import json
import time
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests
import psycopg2
import psycopg2.extras
import numpy as np

# pgvector adapter
try:
    # for psycopg2 usage
    from pgvector.psycopg2 import register_vector as register_vector_psycopg2
except Exception:
    register_vector_psycopg2 = None

# Optional Neo4j
try:
    from neo4j import GraphDatabase, basic_auth
    _HAS_NEO4J = True
except Exception:
    _HAS_NEO4J = False

app = FastAPI(title="KB Table Reader + pgvector search", version="1.2")

# ENV
DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")
NEO4J_URI = os.environ.get("NEO4J_URI")
NEO4J_USER = os.environ.get("NEO4J_USER")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL required")

# DB helpers
def get_pg_conn():
    conn = psycopg2.connect(DATABASE_URL)
    # register pgvector adapter on the DB connection so we can pass numpy arrays directly
    try:
        if register_vector_psycopg2:
            # arrays=True allows working with vector arrays (if used)
            register_vector_psycopg2(conn, arrays=True)
    except Exception:
        # if registration fails, still continue; you'll get a type error if you pass numpy arrays without registration
        pass
    return conn

def get_neo_driver():
    if not _HAS_NEO4J:
        return None
    if not NEO4J_URI:
        return None
    return GraphDatabase.driver(NEO4J_URI, auth=basic_auth(NEO4J_USER, NEO4J_PASSWORD))

# Embedding adapter (unchanged)
def call_embedding_api(texts: List[str]) -> List[List[float]]:
    if not EMBEDDING_API_URL:
        raise RuntimeError("EMBEDDING_API_URL not configured")
    headers = {"Content-Type": "application/json"}
    if EMBEDDING_API_KEY:
        headers["Authorization"] = f"Bearer {EMBEDDING_API_KEY}"
    payload = {"input": texts}
    resp = requests.post(EMBEDDING_API_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    j = resp.json()
    if isinstance(j, dict) and "data" in j:
        return [d["embedding"] for d in j["data"]]
    if isinstance(j, dict) and "embeddings" in j:
        return j["embeddings"]
    if isinstance(j, list) and isinstance(j[0], dict) and "embedding" in j[0]:
        return [d["embedding"] for d in j]
    raise RuntimeError("Unrecognized embedding response format")

# numeric helper
def cosine(a: List[float], b: List[float]) -> float:
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    denom = (np.linalg.norm(a) * np.linalg.norm(b)) + 1e-9
    return float((a @ b) / denom)

# Request models
class SearchAllReq(BaseModel):
    query: str
    top_k: int = 10
    file_ids: Optional[List[str]] = None

class PgvectorSearchReq(BaseModel):
    query: str
    top_k: int = 10
    file_ids: Optional[List[str]] = None
    # distance_metric can be 'cosine' or 'l2' or 'ip'
    distance_metric: Optional[str] = "cosine"

class KGTemplateReq(BaseModel):
    template_name: str
    params: Optional[Dict[str, Any]] = None
    limit: int = 100

# ------------ Existing endpoints (unchanged) ------------
@app.get("/ping")
def ping():
    return {"ok": True}

# Keep your previous /search-all and /fuzzy-all-tables endpoints here if you like
# For brevity, omitted in this snippet (they are unchanged) — we add pgvector variant below.

# ------------ New: /search-all-pgvector (pgvector SQL-backed) ------------
@app.post("/search-all-pgvector")
def search_all_pgvector(req: PgvectorSearchReq):
    """
    Fast pgvector-backed search.
    Implementation notes:
     - Creates an embedding for the query
     - Executes a SQL nearest-neighbor query using pgvector operators
       * '<->' for L2 (Euclidean) distance
       * '<=>' for cosine distance (lower is more similar)
       * '<#>' for (negative) inner product
     - Returns top_k hits grouped by file
    """
    q = req.query
    top_k = int(req.top_k or 10)
    metric = (req.distance_metric or "cosine").lower()
    file_ids = req.file_ids

    # embed the query
    qemb = call_embedding_api([q])[0]

    # Prepare DB query and operator
    # For pgvector:
    #   - L2 distance operator: <->   (smaller = closer)
    #   - Cosine distance operator: <=> (smaller = closer)
    # We'll SELECT the distance and convert to similarity for readability
    if metric == "l2":
        op = "<->"
        compute_similarity = lambda d: 1.0 / (1.0 + d)  # heuristic convert (smaller -> bigger)
    elif metric in ("ip", "inner", "inner_product"):
        op = "<#>"  # returns negative inner product by design; bigger (less negative) -> more similar, but ordering is ascending by returned value so we keep that in mind
        compute_similarity = lambda d: -d
    else:
        # default cosine
        op = "<=>"
        compute_similarity = lambda d: 1.0 - d  # cosine_similarity = 1 - cosine_distance

    conn = get_pg_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            # register_vector was called at connection time in get_pg_conn()
            # Build SQL. We pass the vector as a parameter; pgvector adapter will adapt numpy arrays / lists to vector literal.
            # If file_ids provided, add a WHERE file_id = ANY(%s)
            if file_ids:
                sql = f"""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path,
                           (chunks.embedding {op} %s) AS distance
                    FROM chunks
                    WHERE embedding IS NOT NULL AND file_id = ANY(%s)
                    ORDER BY distance ASC
                    LIMIT %s
                """
                params = (qemb, file_ids, top_k)
            else:
                sql = f"""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path,
                           (chunks.embedding {op} %s) AS distance
                    FROM chunks
                    WHERE embedding IS NOT NULL
                    ORDER BY distance ASC
                    LIMIT %s
                """
                params = (qemb, top_k)

            cur.execute(sql, params)
            rows = cur.fetchall()

        # convert distances into similarity and group
        grouped = {}
        for r in rows:
            fid = str(r["file_id"])
            sim = compute_similarity(r["distance"] if r.get("distance") is not None else 0.0)
            entry = {
                "score": float(sim),
                "distance": float(r["distance"]) if r.get("distance") is not None else None,
                "chunk_id": str(r["id"]),
                "page_number": r.get("page_number"),
                "text": r.get("text"),
                "storage_path": r.get("storage_path"),
                "thumbnail_path": r.get("thumbnail_path")
            }
            grouped.setdefault(fid, {"file_id": fid, "hits": []})
            grouped[fid]["hits"].append(entry)

        return {"query": q, "metric": metric, "results": list(grouped.values())}

    finally:
        conn.close()

# ------------ Hardened KG reasoning: allowlisted templates ------------
# Define templates here. Add new templates as needed.
KG_CYPHER_TEMPLATES = {
    # Finds chunks that mention an entity label, grouped by document
    "find_entity_mentions": {
        "description": "Find chunks that mention a given entity label (exact match) and return filename + context.",
        "cypher": """
            MATCH (en:Entity {label:$entity_label})<-[:MENTIONS_ENTITY]-(ck:Chunk)
            OPTIONAL MATCH (d:Document)-[:HAS_CHUNK]->(ck)
            RETURN d.id AS file_id, d.filename AS filename, ck.id AS chunk_id, ck.text AS text, ck.page_number AS page
            LIMIT $limit
        """,
        "required_params": ["entity_label"]
    },

    # Find tables that contain a numeric parameter matching a regex or exact string
    "find_table_rows_by_text": {
        "description": "Find table rows whose flattened text matches a given substring (case-insensitive).",
        "cypher": """
            MATCH (t:Table)-[:HAS_ROW]->(r:Row)-[:HAS_CELL]->(c:Cell)
            WHERE toLower(c.text) CONTAINS toLower($substring)
            OPTIONAL MATCH (p:Page)-[:HAS_TABLE]->(t)
            OPTIONAL MATCH (d:Document)-[:HAS_CHUNK]->(ck)
            RETURN t.id AS table_id, d.id AS file_id, d.filename AS filename, c.text AS matched_text, c.r AS row_index, c.c AS col_index
            LIMIT $limit
        """,
        "required_params": ["substring"]
    }
}

@app.post("/kg-reason-template")
def kg_reason_template(req: KGTemplateReq):
    """
    Execute a parameterized, allowlisted Cypher template.
    This prevents arbitrary Cypher execution.
    """
    if not _HAS_NEO4J or not NEO4J_URI:
        raise HTTPException(status_code=503, detail="Neo4j not configured")

    tpl = KG_CYPHER_TEMPLATES.get(req.template_name)
    if not tpl:
        raise HTTPException(status_code=400, detail=f"Template not found: {req.template_name}")

    # check required parameters
    for p in tpl.get("required_params", []):
        if not req.params or p not in req.params:
            raise HTTPException(status_code=400, detail=f"Missing required param: {p}")

    driver = get_neo_driver()
    try:
        with driver.session() as sess:
            params = dict(req.params or {})
            params["limit"] = int(req.limit or 100)
            result = sess.run(tpl["cypher"], **params)
            records = [r.data() for r in result]
            return {"template": req.template_name, "records": records}
    finally:
        try:
            driver.close()
        except:
            pass

# You can keep the other endpoints (/fuzzy-all-tables, /compare-docs) as-is (not repeated here).
# End of file.
