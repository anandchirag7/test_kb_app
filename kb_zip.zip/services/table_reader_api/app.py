#!/usr/bin/env python3
"""
table_reader_api/app.py — Extended with:
- /search-all        : global semantic search across chunks
- /fuzzy-all-tables  : global fuzzy search across all table rows
- /compare-docs      : compare metric across docs (RAG style)
- /kg-reason         : run parameterized multi-hop Cypher queries

Environment variables required:
- DATABASE_URL
- EMBEDDING_API_URL
- EMBEDDING_API_KEY (optional)
- NEO4J_URI (optional for kg-reason)
- NEO4J_USER
- NEO4J_PASSWORD
"""

import os
import json
import math
import time
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests
import psycopg2
import psycopg2.extras
import numpy as np

# pgvector adapter
try:
    # for psycopg2 usage
    from pgvector.psycopg2 import register_vector as register_vector_psycopg2
except Exception:
    register_vector_psycopg2 = None

# Optional Neo4j
try:
    from neo4j import GraphDatabase, basic_auth
    _HAS_NEO4J = True
except Exception:
    _HAS_NEO4J = False

app = FastAPI(title="KB Table Reader + Global Search", version="1.1")

# ---- ENV ----
DATABASE_URL = os.environ.get("DATABASE_URL")
EMBEDDING_API_URL = os.environ.get("EMBEDDING_API_URL")
EMBEDDING_API_KEY = os.environ.get("EMBEDDING_API_KEY")
NEO4J_URI = os.environ.get("NEO4J_URI")
NEO4J_USER = os.environ.get("NEO4J_USER")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL required")

# DB helpers
def get_pg_conn():
    conn = psycopg2.connect(DATABASE_URL)
    # register pgvector adapter on the DB connection so we can pass numpy arrays directly
    try:
        if register_vector_psycopg2:
            # arrays=True allows working with vector arrays (if used)
            register_vector_psycopg2(conn, arrays=True)
    except Exception:
        # if registration fails, still continue; you'll get a type error if you pass numpy arrays without registration
        pass
    return conn

def get_neo_driver():
    if not _HAS_NEO4J:
        return None
    if not NEO4J_URI:
        return None
    return GraphDatabase.driver(NEO4J_URI, auth=basic_auth(NEO4J_USER, NEO4J_PASSWORD))


# ---- Embedding adapter ----
def call_embedding_api(texts: List[str]) -> List[List[float]]:
    if not EMBEDDING_API_URL:
        raise RuntimeError("EMBEDDING_API_URL not configured")
    headers = {"Content-Type": "application/json"}
    if EMBEDDING_API_KEY:
        headers["Authorization"] = f"Bearer {EMBEDDING_API_KEY}"
    payload = {"input": texts}
    resp = requests.post(EMBEDDING_API_URL, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    j = resp.json()
    # try common motifs
    if isinstance(j, dict) and "data" in j:
        return [d["embedding"] for d in j["data"]]
    if isinstance(j, dict) and "embeddings" in j:
        return j["embeddings"]
    if isinstance(j, list) and isinstance(j[0], dict) and "embedding" in j[0]:
        return [d["embedding"] for d in j]
    raise RuntimeError("Unrecognized embedding response format")

# ---- numeric helpers ----
def cosine(a: List[float], b: List[float]) -> float:
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    denom = (np.linalg.norm(a) * np.linalg.norm(b)) + 1e-9
    return float((a @ b) / denom)

# ---- Request models ----
class SearchAllReq(BaseModel):
    query: str
    top_k: int = 10
    file_ids: Optional[List[str]] = None  # optional restrict

class FuzzyAllTablesReq(BaseModel):
    query: str
    top_k: int = 10
    table_ids: Optional[List[str]] = None  # optional restrict which tables

class CompareDocsReq(BaseModel):
    query: str                 # what to compare, e.g. "forward voltage at 100mA"
    top_k_per_doc: int = 3
    docs: Optional[List[str]] = None     # optional list of file ids to compare
    prefer_table_rows: bool = True

class KGReasonReq(BaseModel):
    cypher: str
    params: Optional[Dict[str, Any]] = None
    limit: int = 100

class PgvectorSearchReq(BaseModel):
    query: str
    top_k: int = 10
    file_ids: Optional[List[str]] = None
    # distance_metric can be 'cosine' or 'l2' or 'ip'
    distance_metric: Optional[str] = "cosine"

class KGTemplateReq(BaseModel):
    template_name: str
    params: Optional[Dict[str, Any]] = None
    limit: int = 100

# ------------ New: /search-all-pgvector (pgvector SQL-backed) ------------
@app.post("/search-all-pgvector")
def search_all_pgvector(req: PgvectorSearchReq):
    """
    Fast pgvector-backed search.
    Implementation notes:
     - Creates an embedding for the query
     - Executes a SQL nearest-neighbor query using pgvector operators
       * '<->' for L2 (Euclidean) distance
       * '<=>' for cosine distance (lower is more similar)
       * '<#>' for (negative) inner product
     - Returns top_k hits grouped by file
    """
    q = req.query
    top_k = int(req.top_k or 10)
    metric = (req.distance_metric or "cosine").lower()
    file_ids = req.file_ids

    # embed the query
    qemb = call_embedding_api([q])[0]

    # Prepare DB query and operator
    # For pgvector:
    #   - L2 distance operator: <->   (smaller = closer)
    #   - Cosine distance operator: <=> (smaller = closer)
    # We'll SELECT the distance and convert to similarity for readability
    if metric == "l2":
        op = "<->"
        compute_similarity = lambda d: 1.0 / (1.0 + d)  # heuristic convert (smaller -> bigger)
    elif metric in ("ip", "inner", "inner_product"):
        op = "<#>"  # returns negative inner product by design; bigger (less negative) -> more similar, but ordering is ascending by returned value so we keep that in mind
        compute_similarity = lambda d: -d
    else:
        # default cosine
        op = "<=>"
        compute_similarity = lambda d: 1.0 - d  # cosine_similarity = 1 - cosine_distance

    conn = get_pg_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            # register_vector was called at connection time in get_pg_conn()
            # Build SQL. We pass the vector as a parameter; pgvector adapter will adapt numpy arrays / lists to vector literal.
            # If file_ids provided, add a WHERE file_id = ANY(%s)
            if file_ids:
                sql = f"""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path,
                           (chunks.embedding {op} %s) AS distance
                    FROM chunks
                    WHERE embedding IS NOT NULL AND file_id = ANY(%s)
                    ORDER BY distance ASC
                    LIMIT %s
                """
                params = (qemb, file_ids, top_k)
            else:
                sql = f"""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path,
                           (chunks.embedding {op} %s) AS distance
                    FROM chunks
                    WHERE embedding IS NOT NULL
                    ORDER BY distance ASC
                    LIMIT %s
                """
                params = (qemb, top_k)

            cur.execute(sql, params)
            rows = cur.fetchall()

        # convert distances into similarity and group
        grouped = {}
        for r in rows:
            fid = str(r["file_id"])
            sim = compute_similarity(r["distance"] if r.get("distance") is not None else 0.0)
            entry = {
                "score": float(sim),
                "distance": float(r["distance"]) if r.get("distance") is not None else None,
                "chunk_id": str(r["id"]),
                "page_number": r.get("page_number"),
                "text": r.get("text"),
                "storage_path": r.get("storage_path"),
                "thumbnail_path": r.get("thumbnail_path")
            }
            grouped.setdefault(fid, {"file_id": fid, "hits": []})
            grouped[fid]["hits"].append(entry)

        return {"query": q, "metric": metric, "results": list(grouped.values())}

    finally:
        conn.close()


# ---- Endpoint: /search-all ----
@app.post("/search-all")
def search_all(req: SearchAllReq):
    """
    Global semantic search across chunks.table/text/image across all files.
    Returns top_k results grouped by file (filename, file_id).
    """
    q = req.query
    top_k = req.top_k
    file_filter = req.file_ids

    # embed the query
    qemb = call_embedding_api([q])[0]

    conn = get_pg()
    results = []
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            # Fetch candidate chunks with embeddings; limit for performance
            # If file_ids provided, restrict by file_id
            if file_filter:
                cur.execute("""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path, embedding
                    FROM chunks
                    WHERE embedding IS NOT NULL AND file_id = ANY(%s)
                    LIMIT 5000
                """, (file_filter,))
            else:
                cur.execute("""
                    SELECT id, file_id, page_number, text, storage_path, thumbnail_path, embedding
                    FROM chunks
                    WHERE embedding IS NOT NULL
                    LIMIT 5000
                """)
            rows = cur.fetchall()

        # compute cosine for candidates
        scored = []
        for r in rows:
            emb = r["embedding"]
            if not emb:
                continue
            s = cosine(qemb, emb)
            scored.append((s, r))
        scored = sorted(scored, key=lambda x: -x[0])[:top_k]

        # group by file info (lookup filename)
        file_ids = list({r["file_id"] for _, r in scored})
        file_map = {}
        if file_ids:
            with conn.cursor() as cur:
                cur.execute("SELECT id, filename FROM files WHERE id = ANY(%s)", (file_ids,))
                for fr in cur.fetchall():
                    file_map[str(fr[0])] = fr[1]

        grouped = {}
        for s, r in scored:
            fid = str(r["file_id"])
            grouped.setdefault(fid, {"file_id": fid, "filename": file_map.get(fid), "hits": []})
            grouped[fid]["hits"].append({
                "score": float(s),
                "chunk_id": str(r["id"]),
                "page_number": r["page_number"],
                "text": r["text"],
                "storage_path": r.get("storage_path"),
                "thumbnail_path": r.get("thumbnail_path")
            })

        return {"query": q, "results": list(grouped.values())}

    finally:
        conn.close()

# ---- Endpoint: /fuzzy-all-tables ----
@app.post("/fuzzy-all-tables")
def fuzzy_all_tables(req: FuzzyAllTablesReq):
    """
    Search across all precomputed table row embeddings and return top_k matches.
    Uses extracted_tables.row_embeddings JSONB which contains:
      [{"row_index":0, "embedding":[...], "text":"...","model":"..."}, ...]
    """
    q = req.query
    top_k = req.top_k
    restrict_table_ids = req.table_ids

    qemb = call_embedding_api([q])[0]

    conn = get_pg()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            if restrict_table_ids:
                cur.execute("""
                    SELECT id, file_id, page_number, row_embeddings
                    FROM extracted_tables
                    WHERE id = ANY(%s)
                """, (restrict_table_ids,))
            else:
                cur.execute("""
                    SELECT id, file_id, page_number, row_embeddings
                    FROM extracted_tables
                    WHERE row_embeddings IS NOT NULL
                    LIMIT 2000
                """)
            tables = cur.fetchall()

        scored = []
        for t in tables:
            tabel_id = str(t["id"])
            file_id = str(t["file_id"])
            page_number = t["page_number"]
            re = t["row_embeddings"] or []
            # re: list of dicts {row_index, embedding, text}
            for r in re:
                emb = r.get("embedding")
                if not emb:
                    continue
                s = cosine(qemb, emb)
                scored.append((s, {
                    "score": float(s),
                    "table_id": tabel_id,
                    "file_id": file_id,
                    "page_number": page_number,
                    "row_index": r.get("row_index"),
                    "text": r.get("text")
                }))
        scored = sorted(scored, key=lambda x: -x[0])[:top_k]

        # group by file->table
        out = {}
        for s, item in scored:
            fid = item["file_id"]
            tid = item["table_id"]
            out.setdefault(fid, {"file_id": fid, "tables": {}})
            out[fid]["tables"].setdefault(tid, {"table_id": tid, "page_number": item["page_number"], "rows": []})
            out[fid]["tables"][tid]["rows"].append({
                "score": item["score"],
                "row_index": item["row_index"],
                "text": item["text"]
            })

        # convert nested dicts to lists
        res = []
        for fid, v in out.items():
            tables_list = []
            for tid, tv in v["tables"].items():
                tables_list.append(tv)
            res.append({"file_id": fid, "tables": tables_list})

        return {"query": q, "matches": res}

    finally:
        conn.close()

# ---- Endpoint: /compare-docs ----
@app.post("/compare-docs")
def compare_docs(req: CompareDocsReq):
    """
    Compare a free-form metric across docs:
     - For each doc, run fuzzy table row search (preferred)
     - Also run chunk-level search and gather top evidence
     - Return aggregated summaries and raw evidence
    """
    q = req.query
    top_k_per_doc = req.top_k_per_doc
    doc_list = req.docs

    # get list of files to compare
    conn = get_pg()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            if doc_list:
                cur.execute("SELECT id, filename FROM files WHERE id = ANY(%s)", (doc_list,))
            else:
                cur.execute("SELECT id, filename FROM files ORDER BY created_at DESC LIMIT 10")
            files = cur.fetchall()

        # prepare an embedding for the query once
        qemb = call_embedding_api([q])[0]

        results = []
        for f in files:
            fid = str(f["id"])
            filename = f["filename"]

            # 1) table row evidence
            table_hits = []
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("""
                    SELECT id, page_number, row_embeddings
                    FROM extracted_tables
                    WHERE file_id = %s AND row_embeddings IS NOT NULL
                """, (fid,))
                trows = cur.fetchall()

            for t in trows:
                for r in (t.get("row_embeddings") or []):
                    emb = r.get("embedding")
                    if not emb:
                        continue
                    table_hits.append((cosine(qemb, emb), {
                        "table_id": str(t["id"]),
                        "page_number": t["page_number"],
                        "row_index": r.get("row_index"),
                        "text": r.get("text")
                    }))

            table_hits = sorted(table_hits, key=lambda x: -x[0])[:top_k_per_doc]

            # 2) chunk evidence (search top N chunks from this file)
            chunk_hits = []
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("""
                    SELECT id, text, embedding, page_number, storage_path, thumbnail_path
                    FROM chunks WHERE file_id = %s AND embedding IS NOT NULL
                    LIMIT 2000
                """, (fid,))
                rows = cur.fetchall()
            for r in rows:
                emb = r.get("embedding")
                if emb:
                    chunk_hits.append((cosine(qemb, emb), {
                        "chunk_id": str(r["id"]),
                        "page_number": r["page_number"],
                        "text": r["text"],
                        "storage_path": r.get("storage_path"),
                        "thumbnail_path": r.get("thumbnail_path")
                    }))
            chunk_hits = sorted(chunk_hits, key=lambda x: -x[0])[:top_k_per_doc]

            results.append({
                "file_id": fid,
                "filename": filename,
                "table_evidence": [{"score": float(s), **h} for s, h in table_hits],
                "chunk_evidence": [{"score": float(s), **h} for s, h in chunk_hits]
            })

        # simple aggregation summary: which doc had highest top score
        doc_summary = sorted(results, key=lambda r: max(
            [item["score"] for item in r["table_evidence"]] + [item["score"] for item in r["chunk_evidence"]] + [0]
        ), reverse=True)

        return {"query": q, "summary_rank": doc_summary, "detailed": results}

    finally:
        conn.close()

# ---- Endpoint: /kg-reason ----
@app.post("/kg-reason")
def kg_reason(req: KGReasonReq):
    """
    Run a parameterized Cypher query against Neo4j and return results.
    Use this for multi-hop KG queries (requires Neo4j).
    NOTE: this endpoint executes arbitrary Cypher supplied by the user.
    For production, restrict allowed queries or use a query template system.
    """
    if not _HAS_NEO4J or not NEO4J_URI:
        raise HTTPException(status_code=503, detail="Neo4j not configured")

    driver = get_neo_driver()
    try:
        with driver.session() as sess:
            # execute with provided params
            params = req.params or {}
            # enforce a limit in application layer if user passes none
            # We let the user-provided cypher contain its own LIMIT as needed
            result = sess.run(req.cypher, **params)
            records = []
            for r in result:
                # convert Node/Relationship/Path to a JSON-friendly dict where possible
                try:
                    records.append(r.data())
                except Exception:
                    # fallback: capture raw string
                    records.append({"raw": str(r)})
            return {"records": records}
    finally:
        try:
            driver.close()
        except:
            pass

KG_CYPHER_TEMPLATES = {
    # Finds chunks that mention an entity label, grouped by document
    "find_entity_mentions": {
        "description": "Find chunks that mention a given entity label (exact match) and return filename + context.",
        "cypher": """
            MATCH (en:Entity {label:$entity_label})<-[:MENTIONS_ENTITY]-(ck:Chunk)
            OPTIONAL MATCH (d:Document)-[:HAS_CHUNK]->(ck)
            RETURN d.id AS file_id, d.filename AS filename, ck.id AS chunk_id, ck.text AS text, ck.page_number AS page
            LIMIT $limit
        """,
        "required_params": ["entity_label"]
    },

    # Find tables that contain a numeric parameter matching a regex or exact string
    "find_table_rows_by_text": {
        "description": "Find table rows whose flattened text matches a given substring (case-insensitive).",
        "cypher": """
            MATCH (t:Table)-[:HAS_ROW]->(r:Row)-[:HAS_CELL]->(c:Cell)
            WHERE toLower(c.text) CONTAINS toLower($substring)
            OPTIONAL MATCH (p:Page)-[:HAS_TABLE]->(t)
            OPTIONAL MATCH (d:Document)-[:HAS_CHUNK]->(ck)
            RETURN t.id AS table_id, d.id AS file_id, d.filename AS filename, c.text AS matched_text, c.r AS row_index, c.c AS col_index
            LIMIT $limit
        """,
        "required_params": ["substring"]
    }
}

@app.post("/kg-reason-template")
def kg_reason_template(req: KGTemplateReq):
    """
    Execute a parameterized, allowlisted Cypher template.
    This prevents arbitrary Cypher execution.
    """
    if not _HAS_NEO4J or not NEO4J_URI:
        raise HTTPException(status_code=503, detail="Neo4j not configured")

    tpl = KG_CYPHER_TEMPLATES.get(req.template_name)
    if not tpl:
        raise HTTPException(status_code=400, detail=f"Template not found: {req.template_name}")

    # check required parameters
    for p in tpl.get("required_params", []):
        if not req.params or p not in req.params:
            raise HTTPException(status_code=400, detail=f"Missing required param: {p}")

    driver = get_neo_driver()
    try:
        with driver.session() as sess:
            params = dict(req.params or {})
            params["limit"] = int(req.limit or 100)
            result = sess.run(tpl["cypher"], **params)
            records = [r.data() for r in result]
            return {"template": req.template_name, "records": records}
    finally:
        try:
            driver.close()
        except:
            pass

# ---- Basic ping route ----
@app.get("/ping")
def ping():
    return {"ok": True, "service": "table_reader_api_plus"}

