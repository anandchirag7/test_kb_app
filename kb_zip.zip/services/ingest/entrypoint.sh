#!/bin/bash
set -e

echo "[INGEST] Waiting for Postgres..."
sleep 5

echo "[INGEST] Starting ingestion worker..."
# This automatically runs the worker in idle mode or as triggered
# You can replace with a real message queue consumer if needed
tail -f /dev/null
# --- INGEST ENTRYPOINT SH --- IGNORE ---